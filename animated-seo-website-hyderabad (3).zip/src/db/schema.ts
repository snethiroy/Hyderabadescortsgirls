import {
  pgTable,
  serial,
  text,
  integer,
  real,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const companions = pgTable("companions", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  height: text("height").notNull(),
  languages: text("languages").notNull(),
  look: text("look").notNull(),
  category: text("category").notNull(), // e.g. VIP Model, Independent, Elite
  basedArea: text("based_area").notNull(),
  priceInr: integer("price_inr").notNull(), // per hour, in ₹
  priceNote: text("price_note").notNull().default("per hour"),
  tagline: text("tagline").notNull(),
  bio: text("bio").notNull(),
  image: text("image").notNull(),
  availability: text("availability").notNull().default("today"), // now | today | request
  featured: boolean("featured").notNull().default(false),
  verified: boolean("verified").notNull().default(true),
  rating: real("rating").notNull().default(4.8),
  reviews: integer("reviews").notNull().default(0),
  years: integer("years").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const enquiries = pgTable("enquiries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  mobile: text("mobile").notNull(),
  area: text("area"),
  forDate: text("for_date"),
  profileSlug: text("profile_slug"),
  message: text("message"),
  source: text("source").notNull().default("website"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Companion = typeof companions.$inferSelect;
export type Enquiry = typeof enquiries.$inferSelect;
