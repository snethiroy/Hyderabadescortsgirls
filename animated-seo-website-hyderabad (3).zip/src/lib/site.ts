// Central site configuration for Hyderabad Escorts Girls (hyderabadescortsgirls.com)

export const site = {
  name: "Hyderabad Escorts Girls",
  shortName: "HEG",
  url:
    process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") ??
    "https://www.hyderabadescortsgirls.com",
  domain: "hyderabadescortsgirls.com",
  tagline: "Hyderabad's #1 Rated VIP & Independent Escort Service",
  description:
    "Hyderabad's #1 rated escort service. Verified VIP & independent high-class companions across Banjara Hills, Gachibowli & all areas. 24/7 discreet booking.",
  title: "Hyderabad Escorts Girls | VIP & Independent Escorts in Hyderabad 24/7",
  phoneDisplay: "+91 70088 33477",
  phoneRaw: "+917008833477",
  whatsapp: "917008833477",
  email: "snethiroy@gmail.com",
  address: {
    street: "Road No. 12, Banjara Hills",
    locality: "Banjara Hills",
    city: "Hyderabad",
    region: "Telangana",
    postalCode: "500034",
    country: "IN",
  },
  geo: { lat: 17.4156, lng: 78.4347 },
  hours: "Open 24/7 — 365 days a year",
  socials: [
    { label: "Instagram", href: "https://www.instagram.com/hyderabadescortsgirls" },
    { label: "X (Twitter)", href: "https://x.com/hydsexortsgirls" },
    { label: "Telegram", href: "https://t.me/hyderabadescortsgirls" },
    { label: "YouTube", href: "https://www.youtube.com/@hyderabadescortsgirls" },
    { label: "Pinterest", href: "https://in.pinterest.com/hyderabadescortsgirls" },
  ],
  keywords: [
    "hyderabad escorts",
    "hyderabad escorts girls",
    "hyderabadescortsgirls",
    "escorts in hyderabad",
    "hyderabad escort service",
    "independent escorts hyderabad",
    "vip escorts hyderabad",
    "high profile escorts hyderabad",
    "high class escorts hyderabad",
    "elite escorts hyderabad",
    "model escorts hyderabad",
    "call girls hyderabad",
    "hyderabad call girls",
    "female escorts hyderabad",
    "outcall escort service hyderabad",
    "incall escorts hyderabad",
    "banjara hills escorts",
    "jubilee hills escorts",
    "gachibowli escorts",
    "hitech city escorts",
    "kondapur escorts",
    "madhapur escorts",
    "somajiguda escorts",
    "begumpet escorts",
    "secunderabad escorts",
    "ameerpet escorts",
    "khairatabad escorts",
    "panjagutta escorts",
    "lakdikapool escorts",
    "escorts in hyderabad 24/7",
    "verified escorts hyderabad",
  ],
} as const;

export const whatsappLink = (message?: string) =>
  `https://wa.me/${site.whatsapp}${
    message ? `?text=${encodeURIComponent(message)}` : ""
  }`;

export const telLink = `tel:${site.phoneRaw}`;
export const mailLink = `mailto:${site.email}`;

export const COMPANY = {
  legal: "Hyderabad Escorts Girls",
  gstinNote: "GSTIN 36XXXXX0000X1Z5 (proprietorship)",
};
