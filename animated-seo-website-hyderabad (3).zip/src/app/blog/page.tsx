import Link from "next/link";
import Image from "next/image";
import { Clock, ArrowRight, PenLine } from "lucide-react";
import { POSTS } from "@/data/posts";
import { site } from "@/lib/site";

export const metadata = {
  title: "Blog — Hyderabad Escort Booking Guides, Rates & Safety Tips",
  description:
    "Expert guides on booking verified escorts in Hyderabad — safety checklists, VIP vs independent comparisons, top areas, rates breakdown and etiquette. Updated February 2026.",
  alternates: { canonical: "/blog" },
};

export default function BlogIndexPage() {
  const [featured, ...rest] = POSTS;
  return (
    <>
      <section className="border-b border-gold-500/15 bg-ink-900/60">
        <div className="mx-auto max-w-7xl px-4 py-12 lg:px-6">
          <p className="inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500"><PenLine size={13} /> Field Notes</p>
          <h1 className="mt-2 font-display text-4xl font-black text-cream sm:text-5xl">The Hyderabad <span className="text-gold-gradient">Companionship Guide</span></h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-cream-dim">Safety, verification, rates and etiquette — written by the coordinators who run 40,000+ bookings a year.</p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-12 lg:px-6">
        {/* Featured post */}
        <Link href={`/blog/${featured.slug}`} className="group grid overflow-hidden rounded-3xl border border-gold-500/20 bg-ink-800 lg:grid-cols-2">
          <div className="relative h-64 overflow-hidden sm:h-80 lg:h-auto">
            <Image src={featured.image} alt={featured.title} fill sizes="(max-width:1024px) 100vw, 50vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-ink-800/60" />
          </div>
          <div className="flex flex-col justify-center p-6 sm:p-10">
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-gold-500">Featured · {new Date(featured.date).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}</span>
            <h2 className="mt-3 font-display text-2xl font-bold leading-snug text-cream transition-colors group-hover:text-gold-300 sm:text-3xl">{featured.title}</h2>
            <p className="mt-3 text-[13px] leading-relaxed text-cream-dim">{featured.excerpt}</p>
            <span className="mt-5 inline-flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-widest text-gold-400">
              Read guide <ArrowRight size={14} className="transition-transform group-hover:translate-x-1.5" />
            </span>
          </div>
        </Link>

        {/* Remaining posts */}
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {rest.map((p) => (
            <Link key={p.slug} href={`/blog/${p.slug}`} className="group flex flex-col overflow-hidden rounded-3xl border border-gold-500/15 bg-ink-800 transition-all hover:border-gold-500/40">
              <div className="relative h-44 overflow-hidden sm:h-52">
                <Image src={p.image} alt={p.title} fill sizes="(max-width:768px) 100vw, 50vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-800 via-ink-800/30 to-transparent" />
              </div>
              <div className="flex flex-1 flex-col p-6">
                <span className="flex items-center gap-3 text-[10px] font-bold uppercase tracking-widest text-cream-dim">
                  {new Date(p.date).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                  <span className="inline-flex items-center gap-1"><Clock size={11} /> {p.readTime}</span>
                </span>
                <h2 className="mt-2 font-display text-xl font-bold leading-snug text-cream transition-colors group-hover:text-gold-300">{p.title}</h2>
                <p className="mt-2 line-clamp-2 text-[12px] leading-relaxed text-cream-dim">{p.excerpt}</p>
                <span className="mt-4 inline-flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-widest text-gold-400">Read <ArrowRight size={12} className="transition-transform group-hover:translate-x-1.5" /></span>
              </div>
            </Link>
          ))}
        </div>
        <p className="mt-8 text-center text-[11px] text-cream-dim/60">Published and maintained by {site.name} — Hyderabad&apos;s verified adult companionship agency since 2014.</p>
      </section>
    </>
  );
}
