import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { Clock, CalendarDays, ChevronRight, MessageCircle, ArrowLeft } from "lucide-react";
import { getPost, POSTS } from "@/data/posts";
import { site, whatsappLink } from "@/lib/site";
import JsonLd from "@/components/json-ld";

export function generateStaticParams() {
  return POSTS.map((p) => ({ slug: p.slug }));
}

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) return { title: "Article Not Found" };
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: {
      type: "article",
      title: post.title,
      description: post.excerpt,
      url: `${site.url}/blog/${post.slug}`,
      publishedTime: post.date,
      images: [{ url: post.image, width: 1200, height: 627, alt: post.title }],
    },
  };
}

export default async function BlogPostPage({ params }: Params) {
  const { slug } = await params;
  const post = getPost(slug);
  if (!post) notFound();

  const articleLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description: post.excerpt,
    image: [`${site.url}${post.image}`],
    datePublished: post.date,
    dateModified: post.date,
    author: { "@type": "Organization", name: site.name, url: site.url },
    publisher: {
      "@type": "Organization",
      name: site.name,
      logo: { "@type": "ImageObject", url: `${site.url}/icon.svg` },
    },
    mainEntityOfPage: `${site.url}/blog/${post.slug}`,
  };
  const breadcrumbLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: site.url },
      { "@type": "ListItem", position: 2, name: "Blog", item: `${site.url}/blog` },
      { "@type": "ListItem", position: 3, name: post.title, item: `${site.url}/blog/${post.slug}` },
    ],
  };

  return (
    <>
      <JsonLd data={articleLd} />
      <JsonLd data={breadcrumbLd} />

      <nav className="border-b border-gold-500/10 bg-ink-900/60" aria-label="Breadcrumb">
        <div className="mx-auto flex max-w-4xl items-center gap-1.5 overflow-x-auto whitespace-nowrap px-4 py-3 text-[11px] text-cream-dim lg:px-6">
          <Link href="/" className="hover:text-gold-300">Home</Link>
          <ChevronRight size={12} />
          <Link href="/blog" className="hover:text-gold-300">Blog</Link>
          <ChevronRight size={12} />
          <span className="text-gold-400">Article</span>
        </div>
      </nav>

      <article className="mx-auto max-w-4xl px-4 py-10 lg:px-6">
        <div className="flex flex-wrap items-center gap-4 text-[10px] font-bold uppercase tracking-widest text-cream-dim">
          <span className="inline-flex items-center gap-1.5"><CalendarDays size={12} className="text-gold-500" />{new Date(post.date).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}</span>
          <span className="inline-flex items-center gap-1.5"><Clock size={12} className="text-gold-500" />{post.readTime}</span>
        </div>
        <h1 className="mt-3 font-display text-3xl font-black leading-tight text-cream sm:text-4xl lg:text-[2.75rem]">{post.title}</h1>

        <div className="relative mt-6 h-56 overflow-hidden rounded-3xl border border-gold-500/20 sm:h-72 lg:h-80">
          <Image src={post.image} alt={post.title} fill priority sizes="(max-width:1024px) 100vw, 896px" className="object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 to-transparent" />
        </div>

        <p className="mt-6 border-l-4 border-gold-500/60 pl-4 font-display text-base italic leading-relaxed text-gold-200/90">{post.excerpt}</p>

        {post.sections.map((s) => (
          <section key={s.heading} className="mt-8">
            <h2 className="font-display text-2xl font-bold text-cream">{s.heading}</h2>
            {s.paragraphs.map((p, i) => (
              <p key={i} className="mt-3 text-[15px] leading-[1.85] text-cream/85">{p}</p>
            ))}
          </section>
        ))}

        {/* In-article CTA */}
        <div className="mt-10 flex flex-col items-center gap-4 rounded-3xl border border-gold-500/30 bg-gradient-to-r from-gold-500/15 to-ink-800 p-8 text-center">
          <h2 className="font-display text-2xl font-bold text-cream">Ready to meet your match?</h2>
          <p className="max-w-md text-sm text-cream-dim">Verified profiles, same-hour dispatch, pay after arrival. One message is all it takes.</p>
          <a href={whatsappLink(`Hello! I read your article "${post.title.slice(0, 60)}" and would like to book.`)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-gold-400 to-gold-600 px-6 py-4 text-sm font-extrabold uppercase tracking-widest text-ink-950 hover:brightness-110">
            <MessageCircle size={18} strokeWidth={2.4} fill="currentColor" /> Book on WhatsApp
          </a>
        </div>

        <Link href="/blog" className="mt-8 inline-flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest text-gold-400 hover:text-gold-300"><ArrowLeft size={14} /> All articles</Link>
      </article>
    </>
  );
}
