import type { MetadataRoute } from "next";
import { AREAS } from "@/data/areas";
import { POSTS } from "@/data/posts";
import { site } from "@/lib/site";
import { db } from "@/db";
import { companions } from "@/db/schema";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const now = new Date();

  const core: MetadataRoute.Sitemap = [
    { url: site.url, lastModified: now, changeFrequency: "daily", priority: 1.0 },
    { url: `${site.url}/companions`, lastModified: now, changeFrequency: "hourly", priority: 0.95 },
    { url: `${site.url}/areas`, lastModified: now, changeFrequency: "weekly", priority: 0.9 },
    { url: `${site.url}/services`, lastModified: now, changeFrequency: "weekly", priority: 0.85 },
    { url: `${site.url}/contact`, lastModified: now, changeFrequency: "monthly", priority: 0.8 },
    { url: `${site.url}/faq`, lastModified: now, changeFrequency: "monthly", priority: 0.7 },
    { url: `${site.url}/about`, lastModified: now, changeFrequency: "monthly", priority: 0.5 },
    { url: `${site.url}/blog`, lastModified: now, changeFrequency: "weekly", priority: 0.6 },
    { url: `${site.url}/privacy`, lastModified: now, changeFrequency: "yearly", priority: 0.2 },
    { url: `${site.url}/terms`, lastModified: now, changeFrequency: "yearly", priority: 0.2 },
    { url: `${site.url}/disclaimer`, lastModified: now, changeFrequency: "yearly", priority: 0.2 },
  ];

  const areaPages: MetadataRoute.Sitemap = AREAS.map((a) => ({
    url: `${site.url}/areas/${a.slug}`,
    lastModified: now,
    changeFrequency: "weekly",
    priority: a.hot ? 0.85 : 0.7,
  }));

  const postPages: MetadataRoute.Sitemap = POSTS.map((p) => ({
    url: `${site.url}/blog/${p.slug}`,
    lastModified: new Date(p.date),
    changeFrequency: "monthly",
    priority: 0.55,
  }));

  let companionPages: MetadataRoute.Sitemap = [];
  try {
    const rows = await db.select({ slug: companions.slug, createdAt: companions.createdAt }).from(companions);
    companionPages = rows.map((r) => ({
      url: `${site.url}/companions/${r.slug}`,
      lastModified: r.createdAt ?? now,
      changeFrequency: "daily" as const,
      priority: 0.75,
    }));
  } catch {
    companionPages = [];
  }

  return [...core, ...areaPages, ...postPages, ...companionPages];
}
