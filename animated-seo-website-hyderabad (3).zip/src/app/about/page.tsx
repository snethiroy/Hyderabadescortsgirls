import Image from "next/image";
import Link from "next/link";
import { Crown, ShieldCheck, HeartHandshake, Clock, BadgeCheck, MessageCircle } from "lucide-react";
import { whatsappLink } from "@/lib/site";
import CountUp from "@/components/count-up";

export const metadata = {
  title: "About Us — Hyderabad's Most Verified Companionship Agency",
  description:
    "Since 2014, Hyderabad Escorts Girls has delivered 40,000+ discreet, verified companion bookings across Hyderabad — ID-checked, consent-first and rated 4.9/5 by 1,900+ guests.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <>
      {/* Hero */}
      <section className="relative isolate overflow-hidden border-b border-gold-500/15">
        <Image src="/images/lobby-5.jpg" alt="" aria-hidden fill priority sizes="100vw" className="-z-10 object-cover object-center" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink-950/95 via-ink-950/80 to-ink-950/20" />
        <div className="mx-auto max-w-7xl px-4 py-16 lg:px-6 lg:py-20">
          <p className="inline-flex items-center gap-2 rounded-full border border-gold-500/40 bg-ink-950/70 px-4 py-1.5 text-[10px] font-bold uppercase tracking-[0.3em] text-gold-300 backdrop-blur"><Crown size={12} /> Est. 2014 · Banjara Hills</p>
          <h1 className="mt-4 max-w-3xl font-display text-4xl font-black leading-tight text-cream sm:text-5xl">Discreet. Verified. <span className="text-gold-gradient">Uncompromisingly Professional.</span></h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-cream/90 sm:text-base">
            Hyderabad Escorts Girls was founded on one belief: premium companionship deserves the same
            verification, safety and etiquette standards as any luxury hospitality service. A decade and
            40,000+ bookings later, that belief runs every dispatch we make.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="border-b border-gold-500/10 bg-ink-900/60">
        <div className="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-gold-500/10 px-4 py-8 text-center sm:grid-cols-4 lg:px-6">
          {[{ v: 12, s: "+", d: "Years serving Hyderabad", o: 0 }, { v: 40000, s: "+", d: "Confirmed bookings", o: 0 }, { v: 150, s: "+", d: "Verified companions", o: 0 }, { v: 4.9, s: "/5", d: "1,900+ guest reviews", o: 1 }].map(({ v, s, d, o }) => (
            <div key={d} className="px-3">
              <p className="font-display text-3xl font-black text-gold-400 sm:text-4xl"><CountUp end={v} suffix={s} decimals={o} /></p>
              <p className="mt-1 text-[10px] font-semibold uppercase tracking-widest text-cream-dim sm:text-[11px]">{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Values */}
      <section className="mx-auto max-w-7xl px-4 py-14 lg:px-6">
        <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">How We Keep the Standard</p>
        <h2 className="mt-2 font-display text-3xl font-bold text-cream">Verification You Can <span className="text-gold-gradient">Actually See</span></h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: ShieldCheck, step: "01", t: "Government ID Check", d: "Aadhaar/PAN + passport photo verification in person before listing. No exceptions, ever." },
            { icon: BadgeCheck, step: "02", t: "Live Photo Match", d: "A live selfie video on onboarding, matched against portfolio images before every booking window." },
            { icon: Clock, step: "03", t: "30-Day Refresh", d: "Profiles re-verified every 30 days. Stale photos come down instantly — fresh faces only." },
            { icon: HeartHandshake, step: "04", t: "Consent-First", d: "Companions set their own boundaries and may decline any request. Guests respect that — or they are blacklisted." },
          ].map(({ icon: Icon, step, t, d }) => (
            <div key={step} className="rounded-2xl border border-gold-500/15 bg-ink-800 p-6">
              <span className="font-display text-4xl font-black text-gold-500/25">{step}</span>
              <Icon size={24} className="mt-2 text-gold-400" />
              <h3 className="mt-2 font-display text-lg font-bold text-cream">{t}</h3>
              <p className="mt-1.5 text-[12px] leading-relaxed text-cream-dim">{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Promise + CTA */}
      <section className="mx-auto max-w-7xl px-4 pb-16 lg:px-6">
        <div className="relative overflow-hidden rounded-3xl border border-gold-500/30">
          <Image src="/images/lobby-1.jpg" alt="" aria-hidden fill sizes="100vw" className="-z-0 object-cover object-center opacity-30" />
          <div className="relative bg-gradient-to-r from-ink-950/60 to-transparent p-8 sm:p-12">
            <h2 className="max-w-lg font-display text-3xl font-black text-cream">Meet the team that never sees your name twice.</h2>
            <p className="mt-3 max-w-lg text-[13px] leading-relaxed text-cream/85">
              Every enquiry is handled by a senior coordinator under NDA. No logs, no lists, no exceptions.
              That is why 78% of our guests become repeat clients — and why we have never had a single data incident.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href={whatsappLink("Hello! I would like to know more about booking with Hyderabad Escorts Girls.")} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-gold-400 to-gold-600 px-6 py-4 text-sm font-extrabold uppercase tracking-widest text-ink-950 hover:brightness-110">
                <MessageCircle size={18} strokeWidth={2.4} fill="currentColor" /> Talk to a Coordinator
              </a>
              <Link href="/companions" className="inline-flex items-center gap-2 rounded-2xl border border-cream/25 px-6 py-4 text-sm font-bold text-cream hover:text-gold-300">Browse Profiles</Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
