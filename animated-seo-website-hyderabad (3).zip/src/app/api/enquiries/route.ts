import { NextResponse } from "next/server";
import { db } from "@/db";
import { enquiries } from "@/db/schema";
import { site } from "@/lib/site";

export const dynamic = "force-dynamic";

const MOBILE_RE = /^\+?[0-9][0-9 ]{9,14}$/;

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  // Honeypot — silently accept and discard bot submissions
  if (typeof body.company === "string" && body.company.length > 0) {
    return NextResponse.json({ ok: true });
  }

  const name = String(body.name ?? "").trim().slice(0, 80);
  const mobile = String(body.mobile ?? "").trim().slice(0, 20);
  const area = String(body.area ?? "").trim().slice(0, 80) || null;
  const forDate = String(body.forDate ?? "").trim().slice(0, 40) || null;
  const message = String(body.message ?? "").trim().slice(0, 1000) || null;
  const source = String(body.source ?? "website").trim().slice(0, 40);

  if (name.length < 2) {
    return NextResponse.json({ ok: false, error: "Please enter your name (min 2 characters)." }, { status: 422 });
  }
  if (!MOBILE_RE.test(mobile)) {
    return NextResponse.json({ ok: false, error: "Please enter a valid 10-digit mobile/WhatsApp number." }, { status: 422 });
  }

  try {
    const [row] = await db
      .insert(enquiries)
      .values({ name, mobile, area, forDate, message, source })
      .returning({ id: enquiries.id });
    return NextResponse.json({ ok: true, id: row.id });
  } catch (err) {
    console.error("enquiries insert failed", err);
    return NextResponse.json(
      { ok: false, error: `Could not save your enquiry right now — WhatsApp us at ${site.phoneDisplay} instead.` },
      { status: 500 }
    );
  }
}
