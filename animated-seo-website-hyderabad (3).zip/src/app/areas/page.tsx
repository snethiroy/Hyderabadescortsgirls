import Link from "next/link";
import Image from "next/image";
import { MapPin, Crown, ChevronRight, Search } from "lucide-react";
import { AREAS } from "@/data/areas";
import { site } from "@/lib/site";
import JsonLd from "@/components/json-ld";

export const metadata = {
  title: "Escorts in All Hyderabad Areas — Banjara Hills, Gachibowli, Hitech City & More",
  description:
    "Doorstep escort service across 32 Hyderabad localities — Banjara Hills, Jubilee Hills, Gachibowli, Hitech City, Kondapur, Secunderabad & more. Verified companions, same-hour 24/7 dispatch.",
  alternates: { canonical: "/areas" },
  openGraph: {
    title: "Escorts in All Hyderabad Areas | Hyderabad Escorts Girls",
    description: "Verified VIP & independent escorts delivered to every Hyderabad neighbourhood — 24/7 same-hour dispatch.",
    url: `${site.url}/areas`,
    images: [{ url: "/images/charminar-1.jpg", width: 1200, height: 627, alt: "Hyderabad skyline — we serve every area" }],
  },
};

export default function AreasIndexPage() {
  const grouped = AREAS.reduce<Record<string, typeof AREAS>>((acc, a) => {
    (acc[a.zone] ??= []).push(a);
    return acc;
  }, {});

  const itemListLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "Hyderabad areas served for escort outcall",
    numberOfItems: AREAS.length,
    itemListElement: AREAS.map((a, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: `Escorts in ${a.name.replace(/\s*\(.*?\)\s*/g, "")}`,
      url: `${site.url}/areas/${a.slug}`,
    })),
  };

  return (
    <>
      <JsonLd data={itemListLd} />
      {/* Hero */}
      <section className="relative isolate overflow-hidden border-b border-gold-500/15">
        <Image
          src="/images/charminar-1.jpg"
          alt="Charminar Hyderabad — Hyderabad Escorts Girls covers every locality of the city"
          fill
          priority
          sizes="100vw"
          className="-z-10 object-cover object-center"
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink-950/95 via-ink-950/75 to-ink-950/20" />
        <div className="mx-auto max-w-7xl px-4 py-16 lg:px-6 lg:py-20">
          <p className="inline-flex items-center gap-2 rounded-full border border-gold-500/40 bg-ink-950/70 px-4 py-1.5 text-[10px] font-bold uppercase tracking-[0.25em] text-gold-300 backdrop-blur">
            <MapPin size={12} /> 32 Areas · One Private Number
          </p>
          <h1 className="mt-4 max-w-3xl font-display text-4xl font-black leading-[1.08] text-cream sm:text-5xl">
            Escorts in <span className="text-gold-gradient">Every Corner of Hyderabad</span>
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-cream/90 sm:text-base">
            West, Central, North, South and East — our verified companions reach Banjara Hills, Jubilee Hills,
            Gachibowli, Hitech City, Secunderabad and every locality below, usually within 20–40 minutes.
            Tap your area for local landmarks, exact PIN codes and area-specific booking notes.
          </p>
        </div>
      </section>

      {/* Area grid grouped by zone */}
      <section className="mx-auto max-w-7xl px-4 py-12 lg:px-6">
        {Object.entries(grouped).map(([zone, areas]) => (
          <div key={zone} className="mb-10">
            <h2 className="flex items-center gap-3 font-display text-xl font-bold uppercase tracking-widest text-gold-400">
              <span className="h-px flex-1 bg-gold-500/20" />{zone}<span className="h-px flex-1 bg-gold-500/20" />
            </h2>
            <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {areas.map((a) => (
                <Link
                  key={a.slug}
                  href={`/areas/${a.slug}`}
                  className="group flex flex-col rounded-2xl border border-gold-500/15 bg-ink-800 p-5 transition-all hover:-translate-y-0.5 hover:border-gold-500/45 hover:shadow-[0_16px_40px_rgba(212,175,55,0.1)]"
                >
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-display text-lg font-bold text-cream group-hover:text-gold-300">
                      Escorts in {a.name.replace(/\s*\(.*?\)\s*/g, "")}
                    </h3>
                    {a.hot && <Crown size={16} className="shrink-0 text-gold-500" fill="currentColor" aria-label="High-demand area" />}
                  </div>
                  <p className="mt-1 text-[10px] font-bold uppercase tracking-widest text-cream-dim">PIN {a.pincode} · Outcall &amp; Incall</p>
                  <p className="mt-2 line-clamp-2 flex-1 text-[11px] leading-relaxed text-cream-dim">{a.blurb}</p>
                  <span className="mt-3 inline-flex items-center gap-1 text-[10px] font-extrabold uppercase tracking-widest text-gold-400">
                    Local escort page <ChevronRight size={12} className="transition-transform group-hover:translate-x-1" />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        ))}
        <p className="rounded-2xl border border-gold-500/15 bg-ink-800 px-5 py-4 text-center text-[11px] text-cream-dim">
          <Search size={12} className="mr-1 inline text-gold-500" /> Can&apos;t see your locality? We still cover it —
          WhatsApp us with your hotel or landmark and we will confirm the nearest verified companion and arrival time.
        </p>
      </section>
    </>
  );
}
