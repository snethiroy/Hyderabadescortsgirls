import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import {
  MapPin, Crown, MessageCircle, Phone, ChevronRight, BadgeCheck, Clock,
  Building2, Landmark, TrainFront, ShieldCheck, Zap, Star,
} from "lucide-react";
import { AREAS, getArea } from "@/data/areas";
import { site, whatsappLink, telLink } from "@/lib/site";
import JsonLd from "@/components/json-ld";

export function generateStaticParams() {
  return AREAS.map((a) => ({ slug: a.slug }));
}

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const area = getArea(slug);
  if (!area) return { title: "Area Not Found" };
  const clean = area.name.replace(/\s*\(.*?\)\s*/g, "");
  const title = `Escorts in ${clean} — Verified VIP Escort Service ${area.pincode}`;
  const description = `Hire verified escorts in ${clean}, Hyderabad — VIP, independent & elite companions near ${area.landmarks[0]}. Same-hour 24/7 dispatch, transparent rates from ₹3,000, total discretion. Call ${site.phoneDisplay}.`;
  return {
    title,
    description,
    keywords: [`escorts in ${clean.toLowerCase()}`, `${clean.toLowerCase()} escorts`, `${clean.toLowerCase()} escort service`, `${clean.toLowerCase()} call girls`, `vip escorts ${clean.toLowerCase()}`, `independent escorts ${clean.toLowerCase()}`, `${clean.toLowerCase()} escorts ${area.pincode}`],
    alternates: { canonical: `/areas/${area.slug}` },
    openGraph: {
      title: `${title} | ${site.name}`,
      description,
      url: `${site.url}/areas/${area.slug}`,
      images: [{ url: "/images/charminar-2.jpg", width: 1200, height: 627, alt: `Escorts in ${clean}, Hyderabad` }],
    },
  };
}

export default async function AreaPage({ params }: Params) {
  const { slug } = await params;
  const area = getArea(slug);
  if (!area) notFound();

  const clean = area.name.replace(/\s*\(.*?\)\s*/g, "");
  const nearbyAreas = (area.nearby
    .map((n) => AREAS.find((a) => a.name.startsWith(n) || n.startsWith(a.name.split(" ")[0])))
    .filter(Boolean) as typeof AREAS).slice(0, 4);

  const breadcrumbLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: site.url },
      { "@type": "ListItem", position: 2, name: "Areas", item: `${site.url}/areas` },
      { "@type": "ListItem", position: 3, name: `Escorts in ${clean}`, item: `${site.url}/areas/${area.slug}` },
    ],
  };
  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: [
      {
        "@type": "Question",
        name: `How fast can an escort arrive in ${clean}?`,
        acceptedAnswer: {
          "@type": "Answer",
          text: `For ${clean} we typically dispatch within 15–30 minutes during peak hours and under 20 minutes most of the day. Share your hotel or landmark (e.g. ${area.landmarks[0]}) on WhatsApp and we confirm exact arrival before dispatch.`,
        },
      },
      {
        "@type": "Question",
        name: `Is the service in ${clean} discreet?`,
        acceptedAnswer: {
          "@type": "Answer",
          text: `Completely. Companions arrive in plain civilian clothing with no branding, contact happens on a private number, and no client details are ever stored or shared. Your visit to ${clean} stays entirely between you and us.`,
        },
      },
    ],
  };
  const serviceLd = {
    "@context": "https://schema.org",
    "@type": "Service",
    serviceType: "Escort companionship service",
    provider: { "@type": "LocalBusiness", name: site.name, telephone: site.phoneRaw, url: site.url },
    areaServed: { "@type": "Place", name: `${clean}, Hyderabad`, postalCode: area.pincode },
    offers: { "@type": "Offer", priceCurrency: "INR", price: "3000", description: "Starting rate per hour" },
  };

  return (
    <>
      <JsonLd data={breadcrumbLd} />
      <JsonLd data={faqLd} />
      <JsonLd data={serviceLd} />

      {/* Breadcrumb */}
      <nav className="border-b border-gold-500/10 bg-ink-900/60" aria-label="Breadcrumb">
        <div className="mx-auto flex max-w-7xl items-center gap-1.5 overflow-x-auto whitespace-nowrap px-4 py-3 text-[11px] text-cream-dim lg:px-6">
          <Link href="/" className="hover:text-gold-300">Home</Link>
          <ChevronRight size={12} className="shrink-0" />
          <Link href="/areas" className="hover:text-gold-300">Areas</Link>
          <ChevronRight size={12} className="shrink-0" />
          <span className="text-gold-400" aria-current="page">Escorts in {clean}</span>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative isolate overflow-hidden">
        <Image
          src="/images/charminar-2.jpg"
          alt={`Hyderabad city — escort service in ${clean}`}
          fill
          priority
          sizes="100vw"
          className="-z-10 object-cover object-center"
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink-950/95 via-ink-950/80 to-ink-950/15" />
        <div className="mx-auto max-w-7xl px-4 py-14 lg:px-6 lg:py-16">
          <p className="inline-flex items-center gap-2 rounded-full border border-gold-500/40 bg-ink-950/70 px-4 py-1.5 text-[10px] font-bold uppercase tracking-[0.25em] text-gold-300 backdrop-blur">
            {area.hot && <Crown size={12} fill="currentColor" />} {clean} · PIN {area.pincode} · {area.zone}
          </p>
          <h1 className="mt-4 max-w-3xl font-display text-4xl font-black leading-[1.08] text-cream sm:text-5xl">
            Escorts in {clean} — <span className="text-gold-gradient">VIP &amp; Independent</span>
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-cream/90 sm:text-base">{area.blurb}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href={whatsappLink(`Hello Hyderabad Escorts Girls! I need a companion in ${clean} (${area.pincode}).`)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-gold-400 to-gold-600 px-6 py-4 text-sm font-extrabold uppercase tracking-widest text-ink-950 shadow-[0_10px_36px_rgba(212,175,55,0.4)] hover:brightness-110"
            >
              <MessageCircle size={18} strokeWidth={2.4} fill="currentColor" /> Book in {clean} Now
            </a>
            <a href={telLink} className="inline-flex items-center gap-2 rounded-2xl border border-cream/25 bg-ink-950/60 px-6 py-4 text-sm font-bold text-cream backdrop-blur hover:text-gold-300">
              <Phone size={17} /> {site.phoneDisplay}
            </a>
          </div>
        </div>
      </section>

      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 lg:grid-cols-3 lg:px-6">
        {/* Main content */}
        <div className="space-y-8 lg:col-span-2">
          {/* Landmarks */}
          <section aria-labelledby="landmarks-heading">
            <h2 id="landmarks-heading" className="flex items-center gap-2 font-display text-2xl font-bold text-cream"><Landmark size={20} className="text-gold-400" /> Key Landmarks We Serve in {clean}</h2>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {area.landmarks.map((lm, i) => {
                const Icon = [Building2, MapPin, TrainFront, Landmark][i % 4];
                return (
                  <div key={lm} className="flex flex-col items-center gap-2 rounded-2xl border border-gold-500/15 bg-ink-800 px-3 py-5 text-center">
                    <Icon size={20} className="text-gold-500" />
                    <span className="text-[11px] font-bold leading-tight text-cream">{lm}</span>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Why book in area */}
          <section aria-labelledby="why-heading">
            <h2 id="why-heading" className="font-display text-2xl font-bold text-cream">Why Guests in {clean} Choose Us</h2>
            <ul className="mt-4 grid gap-3 sm:grid-cols-2">
              {[
                { icon: Zap, t: "Fastest arrival in the city", d: `Average 15–30 min dispatch to any ${clean} hotel or residence, tracked live.` },
                { icon: ShieldCheck, t: "100% verified profiles", d: "Government-ID + live selfie verification, refreshed every 30 days." },
                { icon: Crown, t: "VIP & independent range", d: "From ₹3,000/hr classics to ₹25,000/hr elite — exact quote before you confirm." },
                { icon: BadgeCheck, t: "Photo-match guarantee", d: "The person who arrives is the booked profile. Otherwise you pay nothing." },
              ].map(({ icon: Icon, t, d }) => (
                <li key={t} className="rounded-2xl border border-gold-500/15 bg-ink-800 p-5">
                  <Icon size={20} className="text-gold-400" />
                  <h3 className="mt-2 text-[13px] font-bold uppercase tracking-wide text-cream">{t}</h3>
                  <p className="mt-1 text-[11px] leading-relaxed text-cream-dim">{d}</p>
                </li>
              ))}
            </ul>
          </section>

          {/* Local FAQ */}
          <section aria-labelledby="area-faq-heading">
            <h2 id="area-faq-heading" className="font-display text-2xl font-bold text-cream">{clean} — Quick Questions</h2>
            <div className="mt-4 space-y-3">
              <details className="rounded-2xl border border-gold-500/15 bg-ink-800 p-5 open:border-gold-500/35">
                <summary className="cursor-pointer list-none text-sm font-bold text-cream"><span className="mr-2 text-gold-500">+</span>How fast can an escort arrive in {clean}?</summary>
                <p className="mt-3 border-t border-gold-500/10 pt-3 text-[12px] leading-relaxed text-cream-dim">
                  Typically 15–30 minutes during peak hours and under 20 minutes most of the day. Share your hotel or landmark (e.g. {area.landmarks[0]}) on WhatsApp and we confirm exact arrival time before dispatch.
                </p>
              </details>
              <details className="rounded-2xl border border-gold-500/15 bg-ink-800 p-5 open:border-gold-500/35">
                <summary className="cursor-pointer list-none text-sm font-bold text-cream"><span className="mr-2 text-gold-500">+</span>Is the service in {clean} completely discreet?</summary>
                <p className="mt-3 border-t border-gold-500/10 pt-3 text-[12px] leading-relaxed text-cream-dim">
                  Completely. Plain clothing, private numbers, no signage, no branding, zero data sharing. Your booking in {clean} stays entirely between you and our coordinator.
                </p>
              </details>
            </div>
          </section>

          {/* Google Map */}
          <section aria-labelledby="map-heading">
            <h2 id="map-heading" className="sr-only">Map of {clean}, Hyderabad</h2>
            <iframe
              title={`Google Maps — ${clean}, Hyderabad`}
              src={`https://www.google.com/maps?q=${encodeURIComponent(`${clean}, Hyderabad`)}&output=embed`}
              className="h-64 w-full rounded-2xl border border-gold-500/15 grayscale invert-[0.92] hue-rotate-180"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </section>
        </div>

        {/* Sidebar */}
        <aside className="space-y-5">
          <div className="rounded-3xl border border-gold-500/30 bg-gradient-to-b from-gold-500/12 to-ink-800 p-6">
            <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.3em] text-gold-500"><Star size={12} /> Book in {clean}</p>
            <p className="mt-3 font-display text-3xl font-black text-cream">₹3,000<span className="text-base font-semibold text-cream-dim"> /hr onwards</span></p>
            <ul className="mt-4 space-y-2 text-[12px] text-cream-dim">
              {["Exact quote before confirmation — no hidden fees", "Cash or UPI after arrival only", "2-hour free cancellation", "Incall apartment near Banjara Hills available"].map((t) => (
                <li key={t} className="flex items-start gap-2"><BadgeCheck size={13} className="mt-0.5 shrink-0 text-emerald-400" />{t}</li>
              ))}
            </ul>
            <a href={whatsappLink(`Hello! I want to book an escort in ${clean}.`)} target="_blank" rel="noopener noreferrer" className="mt-5 flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-gold-400 to-gold-600 px-5 py-4 text-sm font-extrabold uppercase tracking-widest text-ink-950 hover:brightness-110">
              <MessageCircle size={17} fill="currentColor" /> WhatsApp Now
            </a>
            <a href={telLink} className="mt-2 flex items-center justify-center gap-2 rounded-2xl border border-gold-500/40 px-5 py-3.5 text-xs font-bold uppercase tracking-widest text-gold-300 hover:border-gold-500">
              <Phone size={15} /> {site.phoneDisplay}
            </a>
            <p className="mt-3 flex items-center justify-center gap-1.5 text-[9px] font-bold uppercase tracking-widest text-cream-dim"><Clock size={11} /> Open 24/7 — Sundays included</p>
          </div>

          {/* Nearby areas */}
          <div className="rounded-3xl border border-gold-500/15 bg-ink-800 p-6">
            <h2 className="text-[10px] font-bold uppercase tracking-[0.3em] text-gold-500">Nearby Areas We Cover</h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {nearbyAreas.map((a) => (
                <Link key={a.slug} href={`/areas/${a.slug}`} className="rounded-full border border-gold-500/25 bg-ink-700 px-3.5 py-1.5 text-[11px] font-semibold text-cream-dim transition-colors hover:border-gold-500/50 hover:text-gold-300">
                  {a.name.replace(/\s*\(.*?\)\s*/g, "")}
                </Link>
              ))}
              <Link href="/areas" className="rounded-full border border-gold-500/40 px-3.5 py-1.5 text-[11px] font-bold text-gold-400 hover:text-gold-300">All 32 areas →</Link>
            </div>
          </div>
        </aside>
      </div>
    </>
  );
}
