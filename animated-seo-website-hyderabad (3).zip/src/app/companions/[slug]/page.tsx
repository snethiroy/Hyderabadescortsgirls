import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import {
  MapPin, Star, BadgeCheck, MessageCircle, Phone, ShieldCheck, Lock, Clock,
  Ruler, Languages, Sparkles, CalendarDays, ChevronRight, Heart,
} from "lucide-react";
import { db } from "@/db";
import { companions } from "@/db/schema";
import { eq, ne, and, desc } from "drizzle-orm";
import CompanionCard from "@/components/companion-card";
import JsonLd from "@/components/json-ld";
import { site, whatsappLink, telLink } from "@/lib/site";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  try {
    const [c] = await db.select().from(companions).where(eq(companions.slug, slug)).limit(1);
    if (!c) return { title: "Companion Not Found" };
    const title = `${c.name} — ${c.category} Escort in ${c.basedArea}, Hyderabad`;
    const description = `Book ${c.name} (${c.age}), verified ${c.category.toLowerCase()} escort in ${c.basedArea}, Hyderabad — ₹${c.priceInr.toLocaleString("en-IN")}/hr. ${c.tagline}. Photo-matched, discreet 24/7 same-hour dispatch. Call ${site.phoneDisplay}.`;
    return {
      title,
      description,
      alternates: { canonical: `/companions/${c.slug}` },
      openGraph: {
        title: `${title} | ${site.name}`,
        description,
        url: `${site.url}/companions/${c.slug}`,
        type: "profile",
        images: [{ url: c.image, width: 800, height: 1200, alt: `${c.name} — ${c.category} escort in ${c.basedArea}, Hyderabad` }],
      },
      twitter: { card: "summary_large_image", title, description, images: [c.image] },
    };
  } catch {
    return { title: "Companion Profile" };
  }
}

const AVAIL = {
  now: { label: "Available Now — same-hour dispatch", cls: "text-emerald-400 border-emerald-500/30 bg-emerald-500/10" },
  today: { label: "Available Today — book before 10 PM", cls: "text-amber-300 border-amber-500/30 bg-amber-500/10" },
  request: { label: "On Request — advance booking required", cls: "text-rose-300 border-rose-500/30 bg-rose-500/10" },
} as const;

export default async function CompanionProfilePage({ params }: Params) {
  const { slug } = await params;
  const [c] = await db.select().from(companions).where(eq(companions.slug, slug)).limit(1).catch(() => [undefined]);

  if (!c) notFound();

  const avail = AVAIL[c.availability as keyof typeof AVAIL] ?? AVAIL.today;
  const similar = await db
    .select()
    .from(companions)
    .where(and(ne(companions.slug, c.slug), eq(companions.category, c.category)))
    .orderBy(desc(companions.rating))
    .limit(3)
    .catch(() => []);

  const breadcrumbLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: site.url },
      { "@type": "ListItem", position: 2, name: "Companions", item: `${site.url}/companions` },
      { "@type": "ListItem", position: 3, name: c.name, item: `${site.url}/companions/${c.slug}` },
    ],
  };
  const profileLd = {
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    name: `${c.name} — ${c.category} escort in ${c.basedArea}`,
    url: `${site.url}/companions/${c.slug}`,
    mainEntity: {
      "@type": "Person",
      name: c.name,
      jobTitle: `${c.category} Companion`,
      knowsLanguage: c.languages.split(",").map((l) => l.trim()),
      address: { "@type": "PostalAddress", addressLocality: `${c.basedArea}, Hyderabad`, addressRegion: "Telangana", addressCountry: "IN" },
      worksFor: { "@type": "Organization", name: site.name, url: site.url },
    },
  };

  const details: [typeof Ruler, string, string][] = [
    [CalendarDays, "Age", `${c.age} years (Adult)`],
    [Ruler, "Height", c.height],
    [Languages, "Languages", c.languages],
    [Sparkles, "Look", c.look],
    [MapPin, "Based In", `${c.basedArea}, Hyderabad`],
    [BadgeCheck, "Experience", `${c.years}+ years`],
  ];

  return (
    <>
      <JsonLd data={breadcrumbLd} />
      <JsonLd data={profileLd} />

      {/* Breadcrumb */}
      <nav className="border-b border-gold-500/10 bg-ink-900/60" aria-label="Breadcrumb">
        <div className="mx-auto flex max-w-7xl items-center gap-1.5 overflow-x-auto whitespace-nowrap px-4 py-3 text-[11px] text-cream-dim lg:px-6">
          <Link href="/" className="hover:text-gold-300">Home</Link>
          <ChevronRight size={12} className="shrink-0" />
          <Link href="/companions" className="hover:text-gold-300">Companions</Link>
          <ChevronRight size={12} className="shrink-0" />
          <span className="text-gold-400" aria-current="page">{c.name}</span>
        </div>
      </nav>

      <div className="mx-auto max-w-7xl px-4 py-8 lg:px-6">
        <div className="grid gap-8 lg:grid-cols-12">
          {/* Photo column */}
          <div className="lg:col-span-5 xl:col-span-4">
            <div className="relative overflow-hidden rounded-3xl border border-gold-500/25 shadow-[0_30px_80px_rgba(0,0,0,0.5)]">
              <Image
                src={c.image}
                alt={`${c.name} — verified ${c.category} escort in ${c.basedArea}, Hyderabad. 18+.`}
                width={800}
                height={1200}
                priority
                className="aspect-[3/4] w-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/85 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                <div>
                  <p className="font-display text-3xl font-black text-cream">{c.name}<span className="ml-2 text-xl font-semibold text-gold-300">{c.age}</span></p>
                  <p className="mt-0.5 text-[11px] font-bold uppercase tracking-widest text-gold-400">{c.category} · {c.basedArea}</p>
                </div>
                <span className="inline-flex items-center gap-1 rounded-full bg-gold-500 px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-widest text-ink-950"><Star size={11} fill="currentColor" /> {c.rating.toFixed(1)}</span>
              </div>
            </div>

            {/* Booking card */}
            <div className="mt-5 rounded-3xl border border-gold-500/30 bg-gradient-to-b from-gold-500/12 to-ink-800 p-5">
              <div className="flex items-end justify-between gap-3 border-b border-gold-500/15 pb-4">
                <div>
                  <p className="font-display text-4xl font-black text-gold-400">₹{c.priceInr.toLocaleString("en-IN")}</p>
                  <p className="mt-0.5 text-[10px] font-bold uppercase tracking-widest text-cream-dim">per hour · all fees included</p>
                </div>
                <p className="text-right text-[10px] font-semibold text-cream-dim">1 hr minimum<br />2 hrs save 5%<br />Overnight on request</p>
              </div>
              <p className={`mt-4 inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest ${avail.cls}`}>
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-current" />{avail.label}
              </p>
              <a
                href={whatsappLink(`Hello Hyderabad Escorts Girls! I would like to book ${c.name} (${c.basedArea}) — ₹${c.priceInr.toLocaleString("en-IN")}/hr.`)}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-gold-400 to-gold-600 px-6 py-4 text-sm font-extrabold uppercase tracking-widest text-ink-950 transition-all hover:brightness-110"
              >
                <MessageCircle size={18} strokeWidth={2.4} fill="currentColor" /> Book {c.name} — WhatsApp
              </a>
              <a href={telLink} className="mt-2 flex w-full items-center justify-center gap-2 rounded-2xl border border-gold-500/40 px-6 py-3.5 text-sm font-bold uppercase tracking-widest text-gold-300 transition-colors hover:border-gold-500">
                <Phone size={17} /> {site.phoneDisplay}
              </a>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5 text-[9px] font-semibold uppercase tracking-wider text-cream-dim">
                <span className="inline-flex items-center gap-1"><ShieldCheck size={11} className="text-emerald-400" /> ID Verified</span>
                <span className="inline-flex items-center gap-1"><Lock size={11} className="text-gold-400" /> Fully Discreet</span>
                <span className="inline-flex items-center gap-1"><Clock size={11} className="text-gold-400" /> On-Time Arrival</span>
              </div>
            </div>
          </div>

          {/* Details column */}
          <div className="lg:col-span-7 xl:col-span-8">
            <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">{c.category} Companion Profile</p>
            <h1 className="mt-1.5 font-display text-4xl font-black leading-tight text-cream sm:text-5xl">{c.name} — <span className="text-gold-gradient">Hyderabad</span></h1>
            <p className="mt-2 font-display text-lg italic text-gold-300">&ldquo;{c.tagline}&rdquo;</p>
            <div className="mt-3 flex flex-wrap items-center gap-3 text-[11px] text-cream-dim">
              <span className="inline-flex items-center gap-1.5"><MapPin size={13} className="text-gold-500" />{c.basedArea}, Hyderabad — incall &amp; outcall</span>
              <span className="inline-flex items-center gap-1.5"><Star size={13} className="text-gold-400" fill="currentColor" />{c.rating.toFixed(1)} rating · {c.reviews} verified reviews</span>
            </div>

            <p className="mt-6 max-w-2xl text-[15px] leading-relaxed text-cream/90">{c.bio}</p>

            {/* Stats grid */}
            <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
              {details.map(([Icon, label, value]) => (
                <div key={label} className="rounded-2xl border border-gold-500/12 bg-ink-800 px-4 py-3.5">
                  <p className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest text-cream-dim"><Icon size={11} className="text-gold-500" />{label}</p>
                  <p className="mt-1 text-[13px] font-bold leading-snug text-cream">{value}</p>
                </div>
              ))}
            </div>

            {/* Inclusions */}
            <div className="mt-6 rounded-2xl border border-gold-500/15 bg-ink-800 p-5">
              <h2 className="flex items-center gap-2 font-display text-lg font-bold text-cream"><Heart size={17} className="text-gold-400" /> What You Can Expect</h2>
              <ul className="mt-3 grid gap-2 text-[12px] text-cream-dim sm:grid-cols-2">
                {[
                  "Genuine, photo-matched companion in your hotel or at our private incall apartment",
                  "Undivided attention, warm conversation and event-appropriate etiquette",
                  "Plain, unbranded attire for complete discretion in lobbies & restaurants",
                  "Clear time boundaries honoured — extension available by mutual agreement",
                  "No pressure, no drama, no hidden fees — ever",
                  "24/7 coordinator support for rescheduling or changes",
                ].map((t) => (
                  <li key={t} className="flex items-start gap-2"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-gold-500" />{t}</li>
                ))}
              </ul>
            </div>

            {/* Photo-match promise */}
            <div className="mt-4 flex flex-wrap items-center gap-3 rounded-2xl border border-emerald-500/25 bg-emerald-500/8 px-5 py-4 text-[12px] text-emerald-200/90">
              <BadgeCheck size={20} className="shrink-0 text-emerald-400" />
              <p><strong>Photo-Match Guarantee.</strong> The person who arrives is the person in the photo — or you pay nothing and get credit on your next booking. Verified 30 days ago.</p>
            </div>
          </div>
        </div>

        {/* Similar companions */}
        {similar.length > 0 && (
          <section className="mt-12" aria-labelledby="similar-heading">
            <h2 id="similar-heading" className="font-display text-2xl font-bold text-cream">Similar {c.category} Companions</h2>
            <div className="mt-5 grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3">
              {similar.map((s) => <CompanionCard key={s.id} c={s} />)}
            </div>
          </section>
        )}
      </div>
    </>
  );
}
