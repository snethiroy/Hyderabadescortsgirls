import Link from "next/link";
import { Suspense } from "react";
import { Users, BadgeCheck, Clock } from "lucide-react";
import { db } from "@/db";
import { companions } from "@/db/schema";
import { desc } from "drizzle-orm";
import CompanionCard from "@/components/companion-card";
import JsonLd from "@/components/json-ld";
import { whatsappLink, site } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "All Verified Escorts in Hyderabad — VIP Models & Independent Profiles",
  description:
    "Browse 150+ ID-verified escort profiles in Hyderabad — VIP models, independent & elite companions. Live availability, transparent rates from ₹3,000/hr, photo-match guarantee. 24/7 booking.",
  alternates: { canonical: "/companions" },
  openGraph: {
    title: "All Verified Escorts in Hyderabad — VIP & Independent Profiles",
    description:
      "ID-verified VIP, independent & elite companions across Hyderabad. Live availability. Photo-match guarantee. 24/7.",
    url: `${site.url}/companions`,
    images: [{ url: "/images/lobby-1.jpg", width: 1920, height: 1200, alt: "Verified escort profiles in Hyderabad" }],
  },
};

const CATEGORIES = ["All", "VIP Model", "Independent", "Elite"] as const;

export default async function CompanionsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const { category } = await searchParams;
  const active = CATEGORIES.includes(category as (typeof CATEGORIES)[number]) ? (category as string) : "All";

  let rows: Awaited<ReturnType<typeof load>> = [];
  try {
    rows = await load();
  } catch {
    rows = [];
  }

  const filtered = active === "All" ? rows : rows.filter((c) => c.category === active);
  const countFor = (cat: string) => (cat === "All" ? rows.length : rows.filter((c) => c.category === cat).length);

  const itemListLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "Verified escorts in Hyderabad",
    numberOfItems: filtered.length,
    itemListElement: filtered.map((c, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: `${c.name} — ${c.category} escort in ${c.basedArea}`,
      url: `${site.url}/companions/${c.slug}`,
    })),
  };

  return (
    <>
      <JsonLd data={itemListLd} />
      {/* Page hero */}
      <section className="border-b border-gold-500/15 bg-ink-900/60">
        <div className="mx-auto max-w-7xl px-4 py-10 lg:px-6">
          <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Our Verified Roster</p>
          <h1 className="mt-2 font-display text-4xl font-black text-cream sm:text-5xl">
            Hyderabad <span className="text-gold-gradient">Escorts Girls</span>
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-cream-dim">
            Every profile below is government-ID verified, photo-matched and re-checked every 30 days.
            Rates are exact and quoted upfront — pay only after arrival, cash or UPI. Tap any card for
            the full profile, or WhatsApp us and we will match you in under 2 minutes.
          </p>
          <div className="mt-4 flex flex-wrap gap-4 text-[11px] font-semibold text-cream-dim">
            <span className="inline-flex items-center gap-1.5"><Users size={13} className="text-gold-400" /> {rows.length} featured profiles</span>
            <span className="inline-flex items-center gap-1.5"><BadgeCheck size={13} className="text-emerald-400" /> 100% verified</span>
            <span className="inline-flex items-center gap-1.5"><Clock size={13} className="text-gold-400" /> Same-hour dispatch, 24/7</span>
          </div>
        </div>
      </section>

      {/* Category filter */}
      <div className="sticky top-16 z-30 border-b border-gold-500/15 bg-ink-950/90 backdrop-blur-xl lg:top-[72px]">
        <div className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 py-3 lg:px-6">
          {CATEGORIES.map((cat) => {
            const isActive = active === cat;
            return (
              <Link
                key={cat}
                href={cat === "All" ? "/companions" : `/companions?category=${encodeURIComponent(cat)}`}
                className={`whitespace-nowrap rounded-xl px-4 py-2.5 text-[11px] font-extrabold uppercase tracking-widest transition-all ${
                  isActive
                    ? "bg-gradient-to-r from-gold-400 to-gold-600 text-ink-950 shadow-[0_6px_18px_rgba(212,175,55,0.35)]"
                    : "border border-gold-500/25 text-gold-300 hover:border-gold-500/50"
                }`}
                aria-current={isActive ? "page" : undefined}
              >
                {cat === "All" ? "All Profiles" : cat === "VIP Model" ? "VIP Models" : cat} · {countFor(cat)}
              </Link>
            );
          })}
        </div>
      </div>

      {/* Grid */}
      <section className="mx-auto max-w-7xl px-4 py-10 lg:px-6">
        <Suspense fallback={null}>
          {filtered.length > 0 ? (
            <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 xl:grid-cols-4">
              {filtered.map((c) => (
                <CompanionCard key={c.id} c={c} />
              ))}
            </div>
          ) : (
            <div className="rounded-2xl border border-gold-500/20 bg-ink-800 p-10 text-center">
              <p className="font-display text-xl font-bold text-cream">All {active} profiles are currently booked</p>
              <p className="mt-2 text-sm text-cream-dim">WhatsApp us and we will arrange the closest verified match instantly.</p>
              <a href={whatsappLink(`Hello! I need an available ${active} companion in Hyderabad.`)} target="_blank" rel="noopener noreferrer" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#25D366] px-6 py-3 text-sm font-extrabold text-[#083b1e]">
                WhatsApp — Find Available Profile
              </a>
            </div>
          )}
        </Suspense>
      </section>
    </>
  );
}

async function load() {
  return db.select().from(companions).orderBy(desc(companions.rating), desc(companions.reviews));
}
