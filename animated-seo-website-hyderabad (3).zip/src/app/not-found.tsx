import Link from "next/link";
import { Crown, MessageCircle, Home, Users } from "lucide-react";
import { whatsappLink } from "@/lib/site";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-2xl flex-col items-center px-6 py-24 text-center">
      <Crown size={44} className="text-gold-500" fill="currentColor" />
      <p className="mt-4 font-display text-7xl font-black text-gold-gradient">404</p>
      <h1 className="mt-2 font-display text-2xl font-bold text-cream">This page checked out of the hotel.</h1>
      <p className="mt-2 max-w-md text-sm text-cream-dim">The link you followed does not exist — but our companions are live 24/7 exactly where you looked for them.</p>
      <div className="mt-6 flex flex-wrap justify-center gap-3">
        <Link href="/" className="inline-flex items-center gap-2 rounded-2xl border border-gold-500/40 px-6 py-3.5 text-sm font-bold text-gold-300 hover:border-gold-500"><Home size={17} /> Home</Link>
        <Link href="/companions" className="inline-flex items-center gap-2 rounded-2xl border border-gold-500/40 px-6 py-3.5 text-sm font-bold text-gold-300 hover:border-gold-500"><Users size={17} /> Companions</Link>
        <a href={whatsappLink("Hello! I was on your site and need help finding a companion.")} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-gold-400 to-gold-600 px-6 py-3.5 text-sm font-extrabold text-ink-950 hover:brightness-110"><MessageCircle size={17} fill="currentColor" /> WhatsApp Us</a>
      </div>
    </div>
  );
}
