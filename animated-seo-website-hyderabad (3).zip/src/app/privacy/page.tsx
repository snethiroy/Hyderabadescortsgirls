import { site, mailLink } from "@/lib/site";

export const metadata = {
  title: "Privacy Policy — Your Discretion, Legally Protected",
  description: "How Hyderabad Escorts Girls collects, uses and protects your data: minimal collection, zero third-party sharing, no retention beyond your booking, 18+ consent and your rights under the DPDP Act 2023.",
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  const sections: [string, string[]][] = [
    ["1. What We Collect — and Why It Is So Little", [
      "To confirm a booking we collect only: your first name or alias, your mobile/WhatsApp number, your preferred area and time, and the message you send us. That is the complete list.",
      "We do not collect government IDs from clients, location history, contacts, photos, browsing data or payment credentials. UPI payments happen inside your own payment app; we never see your card or bank details.",
    ]],
    ["2. How Long We Keep It", [
      "Booking conversations are deleted within 30 days of the completed booking, or immediately upon request. Enquiry form entries are purged every 30 days. We run no external analytics beyond privacy-friendly, aggregate page counts.",
      "If you asked for a callback that never connected, the entry is deleted within 72 hours of the scheduled slot.",
    ]],
    ["3. Who We Share With — Nobody", [
      "We never sell, rent, trade or leak your details. Your information is shared only with the dispatched coordinator and, on a need-to-know basis (area and time), the confirmed companion — nothing else.",
      "Our hosting provider stores website files only; the enquiry database is access-controlled, encrypted at rest, and located in India.",
    ]],
    ["4. Cookies & Tracking", [
      "This site sets a single functional flag (heg-age-verified) in your browser's localStorage to remember that you confirmed you are 18+. No advertising cookies, no cross-site trackers, no fingerprinting.",
    ]],
    ["5. Your Rights (DPDP Act 2023)", [
      "You may request access, correction, erasure of any data we hold, or withdraw consent at any time — email us or WhatsApp and we action it within 72 hours. Grievance Officer: snethiroy@gmail.com.",
    ]],
    ["6. Children & Adults", [
      "This service is strictly 18+. We do not knowingly collect data from anyone under 18, and any discovery results in immediate deletion and blacklisting of the session.",
    ]],
    ["7. Changes", [
      "We may update this policy; material changes are posted on this page with an updated date. Continued use after notice constitutes acceptance.",
    ]],
  ];

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 lg:px-6">
      <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Legal</p>
      <h1 className="mt-2 font-display text-4xl font-black text-cream">Privacy <span className="text-gold-gradient">Policy</span></h1>
      <p className="mt-2 text-[11px] uppercase tracking-widest text-cream-dim">Last updated: 1 February 2026 · {site.domain}</p>
      {sections.map(([title, paras]) => (
        <section key={title} className="mt-8">
          <h2 className="font-display text-xl font-bold text-gold-300">{title}</h2>
          {paras.map((p, i) => <p key={i} className="mt-2 text-[13px] leading-relaxed text-cream-dim">{p}</p>)}
        </section>
      ))}
      <p className="mt-10 rounded-2xl border border-gold-500/20 bg-ink-800 p-5 text-[12px] text-cream-dim">
        Questions about your data? Write to <a href={mailLink} className="font-bold text-gold-400 hover:text-gold-300">{site.email}</a> — a human reads and answers every message.
      </p>
    </div>
  );
}
