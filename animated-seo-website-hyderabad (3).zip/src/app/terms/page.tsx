import { site, mailLink } from "@/lib/site";

export const metadata = {
  title: "Terms of Service — Adult Companionship & Dating",
  description: "Terms for Hyderabad Escorts Girls: 18+ eligibility, companionship-only scope, booking & cancellation rules, payment terms, photo-match guarantee, blacklist policy and governing law.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  const sections: [string, string[]][] = [
    ["1. Scope of Service — Companionship Only", [
      `${site.name} provides social companionship, dating accompaniment and event-escort services to consenting adults (18+). We do not offer, solicit, broker, arrange or facilitate sexual services of any kind, and no website content should be read as doing so.`,
      "Companions are independent adults, not employees. Each sets her own boundaries and may decline any request at any time, before or during a meeting, without liability.",
    ]],
    ["2. Eligibility", [
      "You must be 18+ and legally permitted to purchase adult companionship services in your jurisdiction. Bookings found to involve minors, trafficking or coercion are reported to authorities and result in a permanent ban.",
    ]],
    ["3. Booking, Arrival & Payment", [
      "A booking is confirmed only after our coordinator calls/WhatsApps you with the companion's first name, area, time and final rate. Rates quoted before confirmation are final — no doorstep negotiation will be entertained.",
      "Payment is due after arrival, by cash or UPI. A token advance is requested only for outstation jobs or peak-hour priority dispatch, and is always adjusted against your bill. We never request gift cards, crypto or bank transfers without a prior video call.",
    ]],
    ["4. Photo-Match Guarantee", [
      "If the companion who arrives is not the booked profile, you pay nothing that day and receive a 100% credit for a future booking. Report mismatches within 10 minutes of arrival via WhatsApp with a photo of the arrival (no faces of staff) for the guarantee to apply.",
    ]],
    ["5. Cancellation & Rescheduling", [
      "Free cancellation or rescheduling up to 2 hours before the slot. Inside 2 hours, any token advance converts to credit (not forfeiture). No-shows forfeit only the token advance, if any.",
    ]],
    ["6. Client Conduct — Zero Tolerance", [
      "Drunk, abusive, aggressive or boundary-violating behaviour gets the meeting terminated instantly with no refund. Recording companions without consent, or sharing their personal details, results in a lifetime blacklist and referral to law enforcement.",
    ]],
    ["7. Liability", [
      "Companionship is an adult leisure service; we are not liable for indirect, emotional or consequential losses. Our total liability for any booking never exceeds the amount paid for it. Nothing in these terms limits rights you hold under Indian consumer law.",
    ]],
    ["8. Governing Law & Jurisdiction", [
      "These terms are governed by the laws of India. Courts in Hyderabad, Telangana have exclusive jurisdiction. If any clause is held invalid, the remainder survives.",
    ]],
  ];

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 lg:px-6">
      <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Legal</p>
      <h1 className="mt-2 font-display text-4xl font-black text-cream">Terms of <span className="text-gold-gradient">Service</span></h1>
      <p className="mt-2 text-[11px] uppercase tracking-widest text-cream-dim">Last updated: 1 February 2026 · {site.domain}</p>
      {sections.map(([title, paras]) => (
        <section key={title} className="mt-8">
          <h2 className="font-display text-xl font-bold text-gold-300">{title}</h2>
          {paras.map((p, i) => <p key={i} className="mt-2 text-[13px] leading-relaxed text-cream-dim">{p}</p>)}
        </section>
      ))}
      <p className="mt-10 rounded-2xl border border-gold-500/20 bg-ink-800 p-5 text-[12px] text-cream-dim">
        Legal queries: <a href={mailLink} className="font-bold text-gold-400 hover:text-gold-300">{site.email}</a> · Grievances are acknowledged within 24 hours and resolved within 7 working days.
      </p>
    </div>
  );
}
