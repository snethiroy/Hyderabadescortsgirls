import Link from "next/link";
import { MessageCircle, ChevronDown, HelpCircle } from "lucide-react";
import { FAQS, FAQ_ITEMSLD } from "@/data/faqs";
import { whatsappLink, telLink, site } from "@/lib/site";
import JsonLd from "@/components/json-ld";

export const metadata = {
  title: "FAQ — Booking, Discretion, Rates & Safety | Hyderabad Escorts Girls",
  description:
    "Answers to 12 common questions about booking verified escorts in Hyderabad — rates from ₹3,000/hr, same-hour dispatch, privacy, verification, cancellation and how to avoid scams.",
  alternates: { canonical: "/faq" },
};

export default function FaqPage() {
  const breadcrumbLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: site.url },
      { "@type": "ListItem", position: 2, name: "FAQ", item: `${site.url}/faq` },
    ],
  };

  return (
    <>
      <JsonLd data={FAQ_ITEMSLD} />
      <JsonLd data={breadcrumbLd} />

      <section className="border-b border-gold-500/15 bg-ink-900/60">
        <div className="mx-auto max-w-7xl px-4 py-12 lg:px-6">
          <p className="inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500"><HelpCircle size={13} /> Honest Answers</p>
          <h1 className="mt-2 font-display text-4xl font-black text-cream sm:text-5xl">Frequently Asked <span className="text-gold-gradient">Questions</span></h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-cream-dim">
            Everything guests ask before their first booking — verification, rates, discretion, timing,
            cancellations and our consent-first policy. Still stuck? Our coordinator replies in under 2 minutes.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-12 lg:px-6">
        <div className="space-y-3">
          {FAQS.map((f, i) => (
            <details key={i} className="group rounded-2xl border border-gold-500/15 bg-ink-800 open:border-gold-500/40">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 p-5">
                <span className="font-display text-[15px] font-bold text-cream transition-colors group-open:text-gold-300 sm:text-base">
                  <span className="mr-2 text-gold-500">{String(i + 1).padStart(2, "0")}</span>{f.q}
                </span>
                <ChevronDown size={18} className="shrink-0 text-gold-500 transition-transform duration-300 group-open:rotate-180" />
              </summary>
              <div className="border-t border-gold-500/10 px-5 pb-5 pt-3">
                <p className="text-[13px] leading-relaxed text-cream-dim">{f.a}</p>
              </div>
            </details>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center gap-4 rounded-3xl border border-gold-500/25 bg-ink-800 p-8 text-center">
          <h2 className="font-display text-2xl font-bold text-cream">Still have a question?</h2>
          <p className="max-w-md text-sm text-cream-dim">Our coordinator answers personally — no bots, no queues, 24/7.</p>
          <a href={whatsappLink("Hello Hyderabad Escorts Girls! I have a question before booking.")} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-gold-400 to-gold-600 px-6 py-4 text-sm font-extrabold uppercase tracking-widest text-ink-950 hover:brightness-110">
            <MessageCircle size={18} strokeWidth={2.4} fill="currentColor" /> Ask on WhatsApp
          </a>
          <a href={telLink} className="text-sm font-bold text-gold-300 hover:text-gold-200">or call {site.phoneDisplay}</a>
        </div>
      </section>
    </>
  );
}
