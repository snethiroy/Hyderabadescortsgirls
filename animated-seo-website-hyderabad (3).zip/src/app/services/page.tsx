import Link from "next/link";
import {
  Crown, Sparkles, UtensilsCrossed, BriefcaseBusiness, Plane, Building2,
  Moon, PartyPopper, Home, Check, MessageCircle, ShieldCheck, Clock, Wallet,
} from "lucide-react";
import { whatsappLink, telLink, site } from "@/lib/site";
import JsonLd from "@/components/json-ld";

export const metadata = {
  title: "Services & Rates — VIP, Independent & Elite Escort Service Hyderabad",
  description:
    "VIP escorts, independent companions, dinner dates, corporate plus-ones, travel escorts, hotel outcalls & incall apartments across Hyderabad. Transparent rates ₹3,000–₹25,000/hr. 24/7.",
  alternates: { canonical: "/services" },
  openGraph: {
    title: "Services & Rates | Hyderabad Escorts Girls",
    description: "Transparent escort rates in Hyderabad — ₹3,000 to ₹25,000/hour. VIP, independent & elite companions. Pay after arrival.",
    url: `${site.url}/services`,
    images: [{ url: "/images/lobby-5.jpg", width: 1200, height: 627, alt: "Hyderabad Escorts Girls services" }],
  },
};

const SERVICES = [
  { id: "vip", icon: Crown, name: "VIP Escort Service", desc: "Agency-verified, magazine-grade models for high-profile evenings — perfect grammar, event etiquette and guaranteed punctuality.", price: "₹8,000–15,000 / hr" },
  { id: "independent", icon: Sparkles, name: "Independent Escorts", desc: "Genuine independent professionals managing their own calendars — warm, personal and the most flexible pricing in the city.", price: "₹3,000–6,000 / hr" },
  { id: "dinner", icon: UtensilsCrossed, name: "Dinner Date Companions", desc: "Restaurant and club dates anywhere in the city — your plus-one arrives presentable, conversation-ready and on time.", price: "₹5,000–12,000 / 3 hrs" },
  { id: "corporate", icon: BriefcaseBusiness, name: "Corporate Event Escorts", desc: "Launch parties, award nights and gala dinners — polished companions who carry any room without drawing the wrong attention.", price: "₹10,000–20,000 / event" },
  { id: "travel", icon: Plane, name: "Travel Companion", desc: "Multi-day accompaniment across India — weddings, conferences, vacations. Itinerary planning and 24/7 availability included.", price: "Custom — per day" },
  { id: "outcall", icon: Building2, name: "Hotel Outcall 24/7", desc: "Your companion reaches 5-star hotels, service apartments or your residence anywhere in Hyderabad — discreet lobby arrival, plain attire.", price: "From ₹3,000 / hr" },
  { id: "incall", icon: Home, name: "Private Incall Apartment", desc: "Book our discreet, hotel-grade private apartments in Banjara Hills — spotless, secure, CCTV-free and by reservation only.", price: "From ₹4,000 / hr" },
  { id: "overnight", icon: Moon, name: "Overnight & Extended", desc: "Full-evening, overnight and multi-hour packages at a flat preferential rate — the best value for unhurried company.", price: "₹20,000–60,000 / night" },
  { id: "party", icon: PartyPopper, name: "Party Plus-One", desc: "Birthday parties, sangeet, house parties — companions who dance, mingle and keep the energy exactly right.", price: "₹8,000–15,000 / party" },
];

const RATES = [
  ["Classic (Independent)", "₹3,000", "₹5,500", "₹10,000", "₹22,000"],
  ["VIP Model", "₹8,000", "₹15,000", "₹28,000", "₹45,000"],
  ["Elite", "₹18,000", "₹34,000", "₹60,000", "On request"],
];

export default function ServicesPage() {
  const catalogLd = {
    "@context": "https://schema.org",
    "@type": "OfferCatalog",
    name: "Hyderabad Escorts Girls — Services & Rates",
    itemListElement: SERVICES.map((s) => ({
      "@type": "Offer",
      itemOffered: { "@type": "Service", name: s.name, description: s.desc },
    })),
  };

  return (
    <>
      <JsonLd data={catalogLd} />
      {/* Hero */}
      <section className="border-b border-gold-500/15 bg-ink-900/60">
        <div className="mx-auto max-w-7xl px-4 py-12 lg:px-6">
          <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Everything We Offer</p>
          <h1 className="mt-2 font-display text-4xl font-black text-cream sm:text-5xl">Escort <span className="text-gold-gradient">Services &amp; Rates</span></h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-cream-dim">
            From a quick hour of company to a full destination wedding weekend — every service below includes
            ID verification, a photo-match guarantee, pay-after-arrival and total discretion. Rates are all-inclusive.
          </p>
          <div className="mt-5 flex flex-wrap gap-4 text-[11px] font-semibold text-cream-dim">
            <span className="inline-flex items-center gap-1.5"><ShieldCheck size={13} className="text-emerald-400" /> Pay after arrival</span>
            <span className="inline-flex items-center gap-1.5"><Clock size={13} className="text-gold-400" /> Zero advance for city incalls</span>
            <span className="inline-flex items-center gap-1.5"><Wallet size={13} className="text-gold-400" /> Cash &amp; UPI accepted</span>
          </div>
        </div>
      </section>

      {/* Services grid */}
      <section className="mx-auto max-w-7xl px-4 py-12 lg:px-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map(({ id, icon: Icon, name, desc, price }) => (
            <div key={id} id={id} className="scroll-mt-28 rounded-2xl border border-gold-500/15 bg-ink-800 p-6 transition-colors hover:border-gold-500/35">
              <span className="grid h-12 w-12 place-items-center rounded-xl bg-gold-500/15 text-gold-400"><Icon size={22} /></span>
              <h2 className="mt-4 font-display text-xl font-bold text-cream">{name}</h2>
              <p className="mt-2 text-[12px] leading-relaxed text-cream-dim">{desc}</p>
              <p className="mt-4 border-t border-gold-500/10 pt-3 text-sm font-extrabold text-gold-400">{price}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Rate table */}
      <section className="mx-auto max-w-7xl px-4 pb-12 lg:px-6" aria-labelledby="rate-table">
        <h2 id="rate-table" className="font-display text-3xl font-bold text-cream">Full <span className="text-gold-gradient">Rate Card</span></h2>
        <div className="mt-5 overflow-x-auto rounded-2xl border border-gold-500/20">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead>
              <tr className="bg-gold-500 text-ink-950">
                <th scope="col" className="px-5 py-4 text-[11px] font-extrabold uppercase tracking-widest">Companion Tier</th>
                <th scope="col" className="px-5 py-4 text-[11px] font-extrabold uppercase tracking-widest">1 Hour</th>
                <th scope="col" className="px-5 py-4 text-[11px] font-extrabold uppercase tracking-widest">2 Hours</th>
                <th scope="col" className="px-5 py-4 text-[11px] font-extrabold uppercase tracking-widest">4 Hours</th>
                <th scope="col" className="px-5 py-4 text-[11px] font-extrabold uppercase tracking-widest">Overnight</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gold-500/10 bg-ink-800 text-cream">
              {RATES.map((row) => (
                <tr key={row[0]} className="transition-colors hover:bg-ink-700/60">
                  <th scope="row" className="px-5 py-4 font-display text-base font-bold text-cream">{row[0]}</th>
                  <td className="px-5 py-4 font-bold text-gold-300">{row[1]}</td>
                  <td className="px-5 py-4 font-bold text-gold-300">{row[2]}</td>
                  <td className="px-5 py-4 font-bold text-gold-300">{row[3]}</td>
                  <td className="px-5 py-4 font-bold text-gold-300">{row[4]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <ul className="mt-4 grid gap-2 text-[11px] text-cream-dim sm:grid-cols-2 lg:grid-cols-4">
          {["All prices include travel within city limits", "Outstation travel billed at cost + ₹2,000/day", "Free cancellation up to 2 hours prior", "Overtime billed pro-rata at the hourly rate"].map((t) => (
            <li key={t} className="flex items-start gap-2"><Check size={13} className="mt-0.5 shrink-0 text-gold-500" />{t}</li>
          ))}
        </ul>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 pb-16 lg:px-6">
        <div className="flex flex-col items-center gap-5 rounded-3xl border border-gold-500/30 bg-gradient-to-r from-gold-500/15 via-ink-800 to-gold-500/10 px-6 py-10 text-center">
          <h2 className="font-display text-2xl font-bold text-cream sm:text-3xl">Not sure which tier fits your evening?</h2>
          <p className="max-w-md text-sm text-cream-dim">Tell us the occasion and budget — our coordinator will match you to the perfect verified profile in under 2 minutes.</p>
          <div className="flex flex-wrap justify-center gap-3">
            <a href={whatsappLink("Hello! Please help me choose the right companion and tier.")} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-gold-400 to-gold-600 px-6 py-4 text-sm font-extrabold uppercase tracking-widest text-ink-950 hover:brightness-110">
              <MessageCircle size={18} strokeWidth={2.4} fill="currentColor" /> WhatsApp — Help Me Choose
            </a>
            <a href={telLink} className="inline-flex items-center gap-2 rounded-2xl border border-gold-500/40 px-6 py-4 text-sm font-bold text-gold-300 hover:border-gold-500">{site.phoneDisplay}</a>
          </div>
        </div>
      </section>
    </>
  );
}
