import { ShieldAlert, CheckCircle2 } from "lucide-react";
import { site } from "@/lib/site";

export const metadata = {
  title: "Disclaimer — 18+ Adult Companionship, Consent & Safety",
  description: "Hyderabad Escorts Girls is an adult social companionship agency — not a sexual services broker. Photos are illustrative, all adults 18+, RTA rated, zero tolerance for exploitation.",
  alternates: { canonical: "/disclaimer" },
};

export default function DisclaimerPage() {
  const points = [
    "Hyderabad Escorts Girls is an adult social companionship and dating agency. We are not a brothel, escort-for-sex broker, or solicitation service, and nothing on this site may be construed as an offer of sexual services for payment.",
    "Every listed individual is an adult (18+) and an independent service provider. Minors are neither listed nor served, and any attempt to involve minors is reported immediately.",
    "Companionship includes conversation, dinner dates, event accompaniment, travel companionship and private company. Any request outside a companion's stated boundaries is refused — every single time.",
    "Photography is professional and illustrative of the listed companion; the photo-match guarantee described in our Terms applies to every booking.",
    "Nothing on this site constitutes medical, legal or financial advice. Testimonials reflect individual guest experiences and are not a promise of outcome.",
    "If you are under 18, pregnant, or find adult material objectionable, please exit now. This site carries the RTA-5042-1996-1400-1577-RTA label and is intended solely for adults.",
    "We support the Immoral Traffic (Prevention) Act, 1956 and all applicable Indian law. We cooperate fully with law enforcement and operate purely as a legal hospitality/companionship business.",
    "If you or someone you know is being exploited or trafficked, call the national helpline 1098 (childline) / 100, or report via www.cybercrime.gov.in. We enforce zero tolerance for exploitation on our platform.",
  ];

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 lg:px-6">
      <p className="inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500"><ShieldAlert size={13} /> Read Before Entering</p>
      <h1 className="mt-2 font-display text-4xl font-black text-cream">Dis<span className="text-gold-gradient">claimer</span></h1>
      <p className="mt-2 text-[11px] uppercase tracking-widest text-cream-dim">{site.domain} · RTA-5042-1996-1400-1577-RTA · 18 U.S.C. not applicable — Indian law governs</p>
      <ul className="mt-8 space-y-4">
        {points.map((p, i) => (
          <li key={i} className="flex items-start gap-3 rounded-2xl border border-gold-500/12 bg-ink-800 p-5 text-[13px] leading-relaxed text-cream-dim">
            <CheckCircle2 size={17} className="mt-0.5 shrink-0 text-gold-500" />
            {p}
          </li>
        ))}
      </ul>
      <p className="mt-8 text-center text-[11px] text-cream-dim/60">© {new Date().getFullYear()} {site.name} · All companions are 18+ independent adults · Companionship only — consent always.</p>
    </div>
  );
}
