import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { site, telLink } from "@/lib/site";
import { AREAS } from "@/data/areas";
import Header from "@/components/header";
import Footer from "@/components/footer";
import WhatsAppFloat from "@/components/whatsapp-float";
import AgeGate from "@/components/age-gate";
import GoogleAnalytics from "@/components/google-analytics";
import JsonLd from "@/components/json-ld";

const orgLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: site.name,
  alternateName: ["Hyderabad Escorts", "HEG Hyderabad", "Hyderabadescortsgirls"],
  description: site.description,
  url: site.url,
  telephone: site.phoneRaw,
  email: site.email,
  image: [`${site.url}/images/lobby-1.jpg`, `${site.url}/images/lobby-2.jpg`, `${site.url}/images/lobby-3.jpg`],
  logo: `${site.url}/icon.svg`,
  priceRange: "₹₹₹",
  currenciesAccepted: "INR",
  paymentAccepted: "Cash, UPI",
  openingHours: "Mo-Su 00:00-23:59",
  address: {
    "@type": "PostalAddress",
    streetAddress: site.address.street,
    addressLocality: site.address.city,
    addressRegion: site.address.region,
    postalCode: site.address.postalCode,
    addressCountry: site.address.country,
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: site.geo.lat,
    longitude: site.geo.lng,
  },
  areaServed: [
    { "@type": "City", name: "Hyderabad" },
    { "@type": "City", name: "Secunderabad" },
    { "@type": "City", name: "Cyberabad" },
    ...AREAS.map((a) => ({ "@type": "Place", name: a.name.replace(/\s*\(.*?\)\s*/g, "") })),
  ],
  sameAs: site.socials.map((s) => s.href),
  knowsLanguage: ["English", "Hindi", "Telugu", "Urdu"],
};

const websiteLd = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: site.name,
  alternateName: "hyderabadescortsgirls.com",
  url: site.url,
  inLanguage: "en-IN",
  publisher: { "@type": "Organization", name: site.name, url: site.url },
  potentialAction: {
    "@type": "SearchAction",
    target: {
      "@type": "EntryPoint",
      urlTemplate: `${site.url}/companions?category={search_term_string}`,
    },
    "query-input": "required name=search_term_string",
  },
};

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: "Hyderabad Escorts Girls | VIP & Independent Escorts in Hyderabad 24/7",
    template: "%s | Hyderabad Escorts Girls",
  },
  description: site.description,
  applicationName: site.name,
  generator: "Next.js",
  referrer: "strict-origin-when-cross-origin",
  keywords: [...site.keywords],
  authors: [{ name: site.name, url: site.url }],
  creator: site.name,
  publisher: site.name,
  category: "escort services",
  classification: "Adult companionship agency",
  alternates: {
    canonical: "/",
    languages: { "en-IN": "/" },
  },
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: site.url,
    siteName: site.name,
    title: "Hyderabad Escorts Girls | VIP & Independent Escorts in Hyderabad 24/7",
    description: site.description,
    images: [
      {
        url: "/images/lobby-3.jpg",
        width: 1200,
        height: 627,
        alt: "Hyderabad Escorts Girls — luxury VIP companionship in Hyderabad",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    site: "@hydsexortsgirls",
    creator: "@hydsexortsgirls",
    title: "Hyderabad Escorts Girls | VIP & Independent Escorts in Hyderabad 24/7",
    description: site.description,
    images: ["/images/lobby-3.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    nocache: false,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: process.env.GOOGLE_SITE_VERIFICATION
    ? { google: process.env.GOOGLE_SITE_VERIFICATION }
    : undefined,
  other: {
    rating: "RTA-5042-1996-1400-1577-RTA",
    distribution: "global",
    audience: "adults",
    "contact:phone_number": site.phoneRaw,
  },
  icons: {
    icon: [{ url: "/icon.svg", type: "image/svg+xml" }],
    shortcut: ["/icon.svg"],
    apple: [{ url: "/icon.svg" }],
  },
};

export const viewport: Viewport = {
  themeColor: "#0c0910",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en-IN">
      <head>
        <link rel="alternate" hrefLang="en-in" href={site.url} />
        <link rel="me" href={site.socials[0].href} />
        <link rel="preconnect" href="https://images.pexels.com" />
        <JsonLd data={orgLd} />
        <JsonLd data={websiteLd} />
      </head>
      <body className="min-h-screen bg-ink-950 font-sans text-cream antialiased">
        <GoogleAnalytics />
        <AgeGate />
        <Header />
        <main id="main" className="relative">{children}</main>
        <Footer />
        <WhatsAppFloat />
        {/* Invisible machine-readable contact anchor */}
        <a href={telLink} aria-hidden="true" tabIndex={-1} className="hidden">
          {site.phoneDisplay}
        </a>
      </body>
    </html>
  );
}
