import Link from "next/link";
import Image from "next/image";
import {
  Crown, MessageCircle, Phone, ShieldCheck, Zap, Lock, BadgePercent, Star,
  BadgeCheck, ChevronRight, Check, MapPin, Clock, Sparkles, Users, CalendarClock,
  Wallet, Quote, UtensilsCrossed, BriefcaseBusiness, Plane, Building2, Moon, PartyPopper,
} from "lucide-react";
import { db } from "@/db";
import { companions } from "@/db/schema";
import { desc } from "drizzle-orm";
import { site, whatsappLink, telLink } from "@/lib/site";
import { AREAS, hotAreas } from "@/data/areas";
import { FAQS } from "@/data/faqs";
import CompanionCard from "@/components/companion-card";
import KeywordCycler from "@/components/keyword-cycler";
import Reveal from "@/components/reveal";
import CountUp from "@/components/count-up";
import JsonLd from "@/components/json-ld";

export const dynamic = "force-dynamic";

export const metadata = {
  alternates: { canonical: "/" },
};

const TESTIMONIALS = [
  { initials: "R.V.", area: "Banjara Hills", rating: 5, text: "Booked for a dinner date at short notice — she matched the profile photo exactly, punctual to the minute and brilliant company. Will book again.", tag: "Dinner Date" },
  { initials: "A.K.", area: "Gachibowli", rating: 5, text: "On a work trip with a brutal week. A 40-minute WhatsApp chat, confirmed slot, companion at my hotel in 25 minutes. Flawless and discreet.", tag: "Hotel Outcall" },
  { initials: "S.M.", area: "Hitech City", rating: 5, text: "Corporate dinner plus-one — she carried the room, knew the etiquette cold. People assumed she was a fund manager's wife. Exceptional.", tag: "Corporate Event" },
  { initials: "D.N.", area: "Jubilee Hills", rating: 5, text: "Third time booking the same companion — always genuine, always on time, never pushy. Best kept secret in Hyderabad.", tag: "Repeat Client" },
  { initials: "P.T.", area: "Begumpet", rating: 5, text: "Arrived as booked, left as booked, charged exactly what was quoted. No drama, no pressure. Total professionalism.", tag: "VIP Model" },
  { initials: "K.S.", area: "Secunderabad", rating: 5, text: "Late-night booking at 2 AM on a weekday — they still managed it. Unmatched availability and the profiles are 100% real.", tag: "Late Night" },
];

const SERVICES = [
  { icon: Crown, label: "VIP Escort Service", href: "/services#vip" },
  { icon: Sparkles, label: "Independent Escorts", href: "/services#independent" },
  { icon: UtensilsCrossed, label: "Dinner Date", href: "/services#dinner" },
  { icon: BriefcaseBusiness, label: "Corporate Events", href: "/services#corporate" },
  { icon: Plane, label: "Travel Companion", href: "/services#travel" },
  { icon: Building2, label: "Hotel Outcall 24/7", href: "/services#outcall" },
  { icon: Moon, label: "Overnight Bookings", href: "/services#overnight" },
  { icon: PartyPopper, label: "Party Plus-One", href: "/services#party" },
];

// Animated marquee of high-volume ranking keywords, internally linked for SEO juice
const KEYWORD_LINKS: { label: string; href: string }[] = [
  { label: "Independent Escorts Hyderabad", href: "/companions?category=Independent" },
  { label: "VIP Escorts Hyderabad", href: "/companions?category=VIP Model" },
  { label: "Elite Companions Hyderabad", href: "/companions?category=Elite" },
  { label: "Escorts in Banjara Hills", href: "/areas/banjara-hills" },
  { label: "Escorts in Gachibowli", href: "/areas/gachibowli" },
  { label: "Escorts in Hitech City", href: "/areas/hitech-city" },
  { label: "Escorts in Jubilee Hills", href: "/areas/jubilee-hills" },
  { label: "Escorts in Kondapur", href: "/areas/kondapur" },
  { label: "Escorts in Madhapur", href: "/areas/madhapur" },
  { label: "Secunderabad Escorts", href: "/areas/secunderabad" },
  { label: "High Profile Escorts Hyderabad", href: "/companions" },
  { label: "Escort Rates in Hyderabad", href: "/services" },
];

export default async function HomePage() {
  let featured: Awaited<ReturnType<typeof getFeatured>> = [];
  try {
    featured = await getFeatured();
  } catch {
    featured = [];
  }

  const itemListLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "Featured escorts in Hyderabad",
    itemListElement: featured.map((c, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: `${c.name} — ${c.category} escort in ${c.basedArea}`,
      url: `${site.url}/companions/${c.slug}`,
    })),
  };

  return (
    <>
      <JsonLd data={itemListLd} />

      {/* ═══════════ HERO ═══════════ */}
      <section className="relative isolate overflow-hidden">
        <Image
          src="/images/lobby-2.jpg"
          alt="Luxury hotel lobby where Hyderabad Escorts Girls arranges discreet companion outcalls"
          fill
          priority
          sizes="100vw"
          className="-z-10 object-cover object-center animate-slow-zoom"
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink-950/97 via-ink-950/80 to-ink-950/15" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-t from-ink-950 via-transparent to-ink-950/60" />
        <div className="mx-auto max-w-7xl px-4 pb-16 pt-14 sm:pb-20 sm:pt-18 lg:px-6 lg:pb-24 lg:pt-20">
          <div className="max-w-2xl">
            <p className="inline-flex items-center gap-2 rounded-full border border-gold-500/40 bg-ink-950/70 px-4 py-1.5 text-[10px] font-bold uppercase tracking-[0.25em] text-gold-300 backdrop-blur">
              <Crown size={12} /> Hyderabad&apos;s #1 Rated Companionship Agency
            </p>
            <h1 className="mt-5 font-display text-[2.6rem] font-black leading-[1.05] text-cream sm:text-6xl lg:text-[4rem]">
              Verified <span className="text-shimmer">VIP Escorts</span> in Hyderabad — 24/7
            </h1>
            {/* Animated ranking-keyword typewriter */}
            <p className="mt-4 flex flex-wrap items-baseline gap-x-3 gap-y-1 text-cream/90">
              <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.3em] text-cream-dim"><Sparkles size={12} className="text-gold-400" /> Most Searched</span>
              <KeywordCycler />
            </p>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-cream/90 sm:text-lg">
              Independent &amp; high-class companions across Banjara Hills, Jubilee Hills, Gachibowli,
              Hitech City and <strong className="text-gold-300">all 32 areas of Hyderabad</strong>.
              ID-verified, photo-matched, discreet to the last detail — and at your door in as little as
              25 minutes.
            </p>
            <div className="mt-7 flex flex-wrap items-center gap-3">
              <a
                href={whatsappLink("Hello Hyderabad Escorts Girls! I would like to book a companion now.")}
                target="_blank"
                rel="noopener noreferrer"
                className="card-sheen inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-gold-400 to-gold-600 px-6 py-4 text-sm font-extrabold uppercase tracking-widest text-ink-950 shadow-[0_12px_40px_rgba(212,175,55,0.4)] transition-all hover:scale-[1.03] hover:brightness-110"
              >
                <MessageCircle size={19} strokeWidth={2.4} fill="currentColor" /> Book on WhatsApp
              </a>
              <a
                href={telLink}
                className="inline-flex items-center gap-2 rounded-2xl border border-cream/25 bg-ink-950/60 px-6 py-4 text-sm font-bold uppercase tracking-widest text-cream backdrop-blur transition-all hover:scale-[1.03] hover:border-gold-500/60 hover:text-gold-300"
              >
                <Phone size={18} /> {site.phoneDisplay}
              </a>
            </div>
            <div className="mt-7 flex flex-wrap items-center gap-x-6 gap-y-3 text-[11px] font-semibold text-cream-dim">
              <span className="inline-flex items-center gap-1.5"><Star size={13} className="text-gold-400" fill="currentColor" /> 4.9 · 1,900+ reviews</span>
              <span className="inline-flex items-center gap-1.5"><BadgeCheck size={13} className="text-emerald-400" /> 100% ID-verified</span>
              <span className="inline-flex items-center gap-1.5"><Clock size={13} className="text-gold-400" /> 24/7 · 365 days</span>
            </div>
          </div>

          {/* Floating trust badges — desktop */}
          <div aria-hidden="true" className="pointer-events-none absolute right-6 top-32 hidden flex-col gap-5 xl:flex 2xl:right-16">
            <div className="animate-float flex items-center gap-3 rounded-2xl border border-emerald-500/35 bg-ink-950/80 px-5 py-3.5 shadow-[0_18px_50px_rgba(16,185,129,0.18)] backdrop-blur">
              <BadgeCheck size={26} className="text-emerald-400" />
              <span><span className="block text-[12px] font-extrabold uppercase tracking-wider text-cream">Photo-Match Verified</span><span className="text-[10px] text-cream-dim">Re-checked every 30 days</span></span>
            </div>
            <div className="animate-float flex items-center gap-3 rounded-2xl border border-gold-500/35 bg-ink-950/80 px-5 py-3.5 shadow-[0_18px_50px_rgba(212,175,55,0.18)] backdrop-blur" style={{ animationDelay: "1.4s" }}>
              <Zap size={26} className="text-gold-400" fill="currentColor" />
              <span><span className="block text-[12px] font-extrabold uppercase tracking-wider text-cream">Same-Hour Dispatch</span><span className="text-[10px] text-cream-dim">Avg 25 min · GPS-tracked arrival</span></span>
            </div>
            <div className="animate-float flex items-center gap-3 rounded-2xl border border-gold-500/35 bg-ink-950/80 px-5 py-3.5 shadow-[0_18px_50px_rgba(212,175,55,0.15)] backdrop-blur" style={{ animationDelay: "2.7s" }}>
              <Star size={26} className="text-gold-400" fill="currentColor" />
              <span><span className="block text-[12px] font-extrabold uppercase tracking-wider text-cream">4.9 ★ Guest Rated</span><span className="text-[10px] text-cream-dim">1,900+ verified booking reviews</span></span>
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ ANIMATED STATS BAR ═══════════ */}
      <section aria-label="Hyderabad Escorts Girls in numbers" className="border-b border-gold-500/15 bg-ink-900/80">
        <div className="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-gold-500/10 px-2 py-6 text-center sm:grid-cols-4 sm:px-4 lg:px-6">
          {[
            { end: 40000, suffix: "+", decimals: 0, label: "Bookings since 2014" },
            { end: 150, suffix: "+", decimals: 0, label: "ID-Verified Profiles" },
            { end: 1900, suffix: "+", decimals: 0, label: "4.9★ Verified Reviews" },
            { end: 32, suffix: "", decimals: 0, label: "Hyderabad Areas Served" },
          ].map(({ end, suffix, decimals, label }) => (
            <div key={label} className="px-3">
              <p className="font-display text-2xl font-black text-gold-400 sm:text-3xl lg:text-4xl">
                <CountUp end={end} suffix={suffix} decimals={decimals} />
              </p>
              <p className="mt-1 text-[9px] font-bold uppercase tracking-[0.18em] text-cream-dim sm:text-[10px]">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ═══════════ DUAL SEO KEYWORD MARQUEES ═══════════ */}
      <div className="overflow-hidden border-b border-gold-500/20 bg-ink-900 py-2" aria-label="Quick links to our area pages">
        <div className="animate-marquee flex items-center gap-7 whitespace-nowrap">
          {[...AREAS, ...AREAS].map((a, i) => (
            <Link
              key={`${a.slug}-${i}`}
              href={`/areas/${a.slug}`}
              tabIndex={-1}
              className="inline-flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.18em] text-cream-dim transition-colors hover:text-gold-300"
            >
              <Crown size={11} className="text-gold-500" /> Escorts in {a.name.replace(/\s*\(.*?\)\s*/g, "")}
            </Link>
          ))}
        </div>
      </div>
      <div className="overflow-hidden border-b border-gold-500/20 bg-ink-950 py-2" aria-label="Trending searches in Hyderabad">
        <div className="animate-marquee-reverse flex items-center gap-7 whitespace-nowrap">
          {[...KEYWORD_LINKS, ...KEYWORD_LINKS].map((k, i) => (
            <Link
              key={`${k.href}-${i}`}
              href={k.href}
              tabIndex={-1}
              className="inline-flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-gold-300/80 transition-colors hover:text-gold-200"
            >
              <Sparkles size={10} className="text-gold-600" /> {k.label}
            </Link>
          ))}
        </div>
      </div>

      {/* ═══════════ FEATURED COMPANIONS ═══════════ */}
      <section className="mx-auto max-w-7xl px-4 py-14 lg:px-6" aria-labelledby="featured-heading">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Handpicked VIP Profiles</p>
              <h2 id="featured-heading" className="mt-2 font-display text-3xl font-bold text-cream sm:text-4xl">
                Featured Companions in <span className="text-gold-gradient">Hyderabad</span>
              </h2>
            </div>
            <Link href="/companions" className="group inline-flex items-center gap-1.5 rounded-xl border border-gold-500/40 px-4 py-2.5 text-xs font-bold uppercase tracking-widest text-gold-300 transition-colors hover:border-gold-500 hover:text-gold-200">
              View all 150+ profiles <ChevronRight size={14} className="transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </Reveal>
        <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 xl:grid-cols-4">
          {featured.map((c, i) => (
            <Reveal key={c.id} delay={Math.min(i, 7) * 70} className="h-full">
              <CompanionCard c={c} />
            </Reveal>
          ))}
        </div>
        <p className="mt-5 text-center text-[11px] text-cream-dim/70">
          Photos refreshed every 30 days · All profiles 18+ and independently verified · Tap any card to view full details
        </p>
      </section>

      {/* ═══════════ WHY CHOOSE US ═══════════ */}
      <section className="relative overflow-hidden border-y border-gold-500/15">
        <Image src="/images/lobby-4.jpg" alt="" aria-hidden fill sizes="100vw" className="-z-10 object-cover object-center" />
        <div className="absolute inset-0 -z-10 bg-ink-950/88" />
        <div className="mx-auto max-w-7xl px-4 py-14 lg:px-6">
          <Reveal>
            <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Why 1,900+ Guests Trust Us</p>
            <h2 className="mt-2 max-w-2xl font-display text-3xl font-bold text-cream sm:text-4xl">Discretion is not a feature. <span className="text-shimmer">It is the foundation.</span></h2>
          </Reveal>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: ShieldCheck, title: "ID-Verified Only", text: "Government-ID and live-selfie verification before any profile goes live. 30-day refresh cycle, no exceptions." },
              { icon: Zap, title: "Same-Hour Dispatch", text: "GPS-tracked arrival in 20–40 minutes across West & Central Hyderabad — and 60 across the rest of the city." },
              { icon: Lock, title: "Military-Grade Discretion", text: "Plain clothing, private numbers, zero data retention. Your booking exists nowhere but this chat." },
              { icon: BadgePercent, title: "No Hidden Charges", text: "One quoted rate before confirmation — cash or UPI after arrival. No doorstep negotiation, ever." },
            ].map(({ icon: Icon, title, text }, i) => (
              <Reveal key={title} delay={i * 90} className="h-full">
                <div className="h-full rounded-2xl border border-gold-500/20 bg-ink-950/70 p-5 backdrop-blur transition-colors hover:border-gold-500/45">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-gold-500/15 text-gold-400"><Icon size={22} /></span>
                  <h3 className="mt-3 font-display text-lg font-bold text-cream">{title}</h3>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-cream-dim">{text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ HOW IT WORKS ═══════════ */}
      <section className="mx-auto max-w-7xl px-4 py-14 lg:px-6" aria-labelledby="how-heading">
        <Reveal>
          <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Zero Friction Booking</p>
          <h2 id="how-heading" className="mt-2 font-display text-3xl font-bold text-cream sm:text-4xl">Booked in <span className="text-shimmer">3 Steps</span></h2>
        </Reveal>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {[
            { n: "01", icon: Users, title: "Pick Your Profile", text: "Browse verified profiles filtered by area, category and budget. Every card shows live availability and exact rates." },
            { n: "02", icon: CalendarClock, title: "Confirm on WhatsApp", text: "Message us the area, hotel, time and duration. We confirm availability in under 2 minutes with a photo-match guarantee." },
            { n: "03", icon: Wallet, title: "Meet & Pay After Arrival", text: "Your companion arrives on time in plain attire. You pay the quoted rate only after arrival — cash or UPI, no advance drama." },
          ].map(({ n, icon: Icon, title, text }, i) => (
            <Reveal key={n} delay={i * 110} className="h-full">
              <div className="group relative h-full overflow-hidden rounded-2xl border border-gold-500/15 bg-ink-800 p-6 transition-colors hover:border-gold-500/35">
                <span className="absolute -right-2 -top-4 font-display text-7xl font-black text-gold-500/10 transition-colors group-hover:text-gold-500/20">{n}</span>
                <Icon size={26} className="text-gold-400" />
                <h3 className="mt-3 font-display text-xl font-bold text-cream">{title}</h3>
                <p className="mt-1.5 text-[13px] leading-relaxed text-cream-dim">{text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ═══════════ SERVICES GRID ═══════════ */}
      <section className="mx-auto max-w-7xl px-4 pb-14 lg:px-6" aria-labelledby="services-heading">
        <Reveal>
          <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Every Occasion, Covered</p>
          <div className="mt-2 flex flex-wrap items-end justify-between gap-3">
            <h2 id="services-heading" className="font-display text-3xl font-bold text-cream sm:text-4xl">Our <span className="text-shimmer">Services</span></h2>
            <Link href="/services" className="text-xs font-bold uppercase tracking-widest text-gold-400 hover:text-gold-300">Full details &amp; rates →</Link>
          </div>
        </Reveal>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {SERVICES.map(({ icon: Icon, label, href }, i) => (
            <Reveal key={label} delay={i * 60}>
              <Link href={href} className="card-sheen flex h-full flex-col items-center gap-2.5 rounded-2xl border border-gold-500/15 bg-ink-800 px-3 py-6 text-center transition-all hover:-translate-y-0.5 hover:border-gold-500/40">
                <Icon size={24} className="text-gold-400" />
                <span className="text-[11px] font-bold uppercase leading-tight tracking-wider text-cream">{label}</span>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ═══════════ RATES TEASER ═══════════ */}
      <section className="mx-auto max-w-7xl px-4 pb-14 lg:px-6" aria-labelledby="rates-heading">
        <Reveal>
          <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Transparent Pricing</p>
          <h2 id="rates-heading" className="mt-2 font-display text-3xl font-bold text-cream sm:text-4xl">Companionship <span className="text-shimmer">Rates</span></h2>
        </Reveal>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {[
            { tier: "Classic", price: "₹3,000–6,000", note: "per hour", items: ["Independent verified profiles", "Incall & outcall", "1-hour minimum", "Same-day booking"], cta: "/companions?category=Independent", featured: false },
            { tier: "VIP", price: "₹8,000–15,000", note: "per hour", items: ["Agency-verified models", "Dinner & event ready", "Photo-match guarantee", "Priority 20-min dispatch", "Free rescheduling"], cta: "/companions?category=VIP Model", featured: true },
            { tier: "Elite", price: "₹18,000–25,000", note: "per hour", items: ["Magazine-grade elite companions", "Multilingual & travel-ready", "Dedicated coordinator", "Overnight packages available", "First-right of refusal booking"], cta: "/companions?category=Elite", featured: false },
          ].map(({ tier, price, note, items, cta, featured: f }) => (
            <Reveal key={tier} delay={f ? 0 : 120} className="h-full">
              <div className={`relative h-full rounded-2xl border p-6 ${f ? "animate-glow border-gold-500/60 bg-gradient-to-b from-gold-500/15 to-ink-800" : "border-gold-500/15 bg-ink-800"}`}>
                {f && <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gold-500 px-3 py-1 text-[9px] font-extrabold uppercase tracking-[0.25em] text-ink-950">Most Booked</span>}
                <h3 className="font-display text-lg font-bold uppercase tracking-widest text-gold-400">{tier}</h3>
                <p className="mt-3 font-display text-3xl font-black text-cream sm:text-4xl">{price}</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-cream-dim">{note}</p>
                <ul className="mt-5 space-y-2 text-[12px] text-cream-dim">
                  {items.map((i) => (
                    <li key={i} className="flex items-start gap-2"><Check size={13} className="mt-0.5 shrink-0 text-gold-500" />{i}</li>
                  ))}
                </ul>
                <Link href={cta} className={`mt-6 block rounded-xl py-3 text-center text-xs font-extrabold uppercase tracking-widest transition-all ${f ? "bg-gradient-to-r from-gold-400 to-gold-600 text-ink-950 hover:brightness-110" : "border border-gold-500/40 text-gold-300 hover:border-gold-500"}`}>
                  View {tier} Profiles
                </Link>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ═══════════ HOT AREAS ═══════════ */}
      <section className="mx-auto max-w-7xl px-4 pb-14 lg:px-6" aria-labelledby="areas-heading">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Citywide Coverage</p>
            <h2 id="areas-heading" className="mt-2 font-display text-3xl font-bold text-cream sm:text-4xl">Escorts in <span className="text-shimmer">Every Area</span></h2>
          </div>
          <Link href="/areas" className="text-xs font-bold uppercase tracking-widest text-gold-400 hover:text-gold-300">All {AREAS.length} areas →</Link>
        </div>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
          {hotAreas.map((a) => (
            <Link key={a.slug} href={`/areas/${a.slug}`} className="group flex flex-col items-center justify-center gap-1.5 rounded-2xl border border-gold-500/15 bg-ink-800 px-2 py-5 text-center transition-all hover:-translate-y-0.5 hover:border-gold-500/45 hover:bg-ink-700">
              <MapPin size={18} className="text-gold-500 transition-transform group-hover:-translate-y-0.5" />
              <span className="text-[10px] font-extrabold uppercase leading-tight tracking-wider text-cream group-hover:text-gold-300">{a.name.replace(/\s*\(.*?\)\s*/g, "")}</span>
              <span className="text-[9px] font-semibold text-cream-dim">PIN {a.pincode}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* ═══════════ TESTIMONIALS ═══════════ */}
      <section className="border-t border-gold-500/10 bg-ink-900/60" aria-labelledby="reviews-heading">
        <div className="mx-auto max-w-7xl px-4 py-14 lg:px-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">Verified Guest Reviews</p>
              <h2 id="reviews-heading" className="mt-2 font-display text-3xl font-bold text-cream sm:text-4xl">Loved Across <span className="text-shimmer">Hyderabad</span></h2>
            </div>
            <div className="flex items-center gap-3 rounded-2xl border border-gold-500/30 bg-ink-800 px-5 py-3">
              <p className="font-display text-3xl font-black text-gold-400"><CountUp end={4.9} decimals={1} duration={1400} /></p>
              <div className="text-left">
                <div className="flex gap-0.5 text-gold-400">{[...Array(5)].map((_, i) => <Star key={i} size={13} fill="currentColor" />)}</div>
                <p className="mt-0.5 text-[10px] font-semibold uppercase tracking-wider text-cream-dim">1,900+ verified reviews</p>
              </div>
            </div>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {TESTIMONIALS.map((t, i) => (
              <Reveal key={`${t.initials}-${t.tag}`} delay={i * 80} className="h-full">
                <figure className="flex h-full flex-col rounded-2xl border border-gold-500/15 bg-ink-800 p-5">
                  <Quote size={18} className="text-gold-600" fill="currentColor" />
                  <blockquote className="mt-2 flex-1 text-[12px] leading-relaxed text-cream/85">&ldquo;{t.text}&rdquo;</blockquote>
                  <figcaption className="mt-4 flex items-center gap-3 border-t border-gold-500/10 pt-4">
                    <span className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-gold-500/40 to-gold-700/40 text-xs font-extrabold text-gold-300">{t.initials}</span>
                    <span>
                      <span className="flex items-center gap-2 text-[12px] font-bold text-cream">{t.initials} · {t.area}
                        <span className="rounded-full bg-ink-700 px-2 py-0.5 text-[8px] font-bold uppercase tracking-wider text-gold-400">{t.tag}</span>
                      </span>
                      <span className="mt-0.5 flex items-center gap-1.5 text-[10px] text-cream-dim">
                        <span className="flex text-gold-400">{[...Array(t.rating)].map((_, i) => <Star key={i} size={10} fill="currentColor" />)}</span>
                        Verified booking
                      </span>
                    </span>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ FAQ TEASER ═══════════ */}
      <section className="mx-auto max-w-7xl px-4 py-14 lg:px-6" aria-labelledby="faq-teaser">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h2 id="faq-teaser" className="font-display text-3xl font-bold text-cream sm:text-4xl">Quick <span className="text-shimmer">Answers</span></h2>
          <Link href="/faq" className="text-xs font-bold uppercase tracking-widest text-gold-400 hover:text-gold-300">Full FAQ (12 questions) →</Link>
        </div>
        <div className="mt-6 grid gap-3 md:grid-cols-2">
          {FAQS.slice(0, 4).map((f) => (
            <details key={f.q} className="group rounded-2xl border border-gold-500/15 bg-ink-800 p-5 transition-colors open:border-gold-500/35">
              <summary className="cursor-pointer list-none font-display text-[15px] font-bold text-cream transition-colors group-open:text-gold-300">
                <span className="mr-2 text-gold-500">+</span>{f.q}
              </summary>
              <p className="mt-3 border-t border-gold-500/10 pt-3 text-[12px] leading-relaxed text-cream-dim">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* ═══════════ FINAL CTA ═══════════ */}
      <section className="relative isolate overflow-hidden">
        <Image src="/images/lobby-3.jpg" alt="" aria-hidden fill sizes="100vw" className="-z-10 object-cover object-center" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink-950/95 via-ink-950/75 to-ink-950/25" />
        <div className="mx-auto max-w-7xl px-4 py-16 text-center sm:py-20 lg:px-6">
          <Crown size={36} className="mx-auto animate-float text-gold-400" fill="currentColor" />
          <h2 className="mx-auto mt-4 max-w-3xl font-display text-3xl font-black leading-tight text-cream sm:text-5xl">
            Tonight in Hyderabad deserves <span className="text-shimmer">a five-star evening.</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-sm text-cream/85 sm:text-base">
            Same-hour dispatch across Banjara Hills, Gachibowli, Hitech City &amp; all areas. One message is all it takes.
          </p>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
            <a href={whatsappLink("Hello! I would like to book a companion tonight.")} target="_blank" rel="noopener noreferrer" className="card-sheen inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-gold-400 to-gold-600 px-7 py-4 text-sm font-extrabold uppercase tracking-widest text-ink-950 shadow-[0_12px_40px_rgba(212,175,55,0.4)] transition-all hover:scale-[1.03]">
              <MessageCircle size={19} strokeWidth={2.4} fill="currentColor" /> WhatsApp — Open Now
            </a>
            <a href={telLink} className="inline-flex items-center gap-2 rounded-2xl border border-cream/30 bg-ink-950/60 px-7 py-4 text-sm font-bold uppercase tracking-widest text-cream backdrop-blur transition-all hover:scale-[1.03] hover:text-gold-300">
              <Phone size={18} /> {site.phoneDisplay}
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

async function getFeatured() {
  return db
    .select()
    .from(companions)
    .orderBy(desc(companions.featured), desc(companions.rating))
    .limit(8);
}
