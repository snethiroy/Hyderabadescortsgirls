import { Phone, MessageCircle, Mail, MapPin, Clock, ShieldCheck, Zap, Star } from "lucide-react";
import BookingForm from "@/components/booking-form";
import { site, telLink, whatsappLink, mailLink } from "@/lib/site";

export const metadata = {
  title: "Book Now — 24/7 Escort Booking Hyderabad | 2-Minute Confirmation",
  description:
    "Book a verified escort in Hyderabad now — WhatsApp, call +91 70088 33477 or send the form. Same-hour dispatch across Banjara Hills, Gachibowli, Hitech City & all areas. Pay after arrival.",
  alternates: { canonical: "/contact" },
  openGraph: {
    title: "Book Now — Hyderabad Escorts Girls 24/7",
    description: "2-minute confirmation. Same-hour dispatch. Pay after arrival. 100% discreet.",
    url: `${site.url}/contact`,
  },
};

export default function ContactPage() {
  return (
    <>
      <section className="border-b border-gold-500/15 bg-ink-900/60">
        <div className="mx-auto max-w-7xl px-4 py-12 lg:px-6">
          <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">2-Minute Confirmation, 24/7</p>
          <h1 className="mt-2 font-display text-4xl font-black text-cream sm:text-5xl">Book Your <span className="text-gold-gradient">Companion</span></h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-cream-dim">
            Three ways to book — WhatsApp is fastest. Share your area, preferred time and profile;
            your companion is dispatched with live tracking. Payment only after arrival.
          </p>
        </div>
      </section>

      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 lg:grid-cols-5 lg:px-6">
        {/* Left — form */}
        <div className="rounded-3xl border border-gold-500/25 bg-ink-800 p-6 sm:p-8 lg:col-span-3">
          <h2 className="flex items-center gap-2 font-display text-2xl font-bold text-cream"><Zap size={20} className="text-gold-400" /> Request Callback</h2>
          <p className="mt-1 text-[12px] text-cream-dim">Fill 30 seconds — our coordinator calls you back within 2 minutes, day or night.</p>
          <div className="mt-6">
            <BookingForm source="contact-page" />
          </div>
        </div>

        {/* Right — channels + map */}
        <div className="space-y-5 lg:col-span-2">
          <div className="rounded-3xl border border-gold-500/25 bg-gradient-to-b from-gold-500/12 to-ink-800 p-6">
            <h2 className="font-display text-xl font-bold text-cream">Instant Channels</h2>
            <div className="mt-4 grid gap-3">
              <a href={whatsappLink("Hello Hyderabad Escorts Girls! I would like to book a companion.")} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 rounded-2xl border border-[#25D366]/40 bg-[#25D366]/10 px-4 py-4 transition-all hover:bg-[#25D366]/15">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#25D366] text-[#083b1e]"><MessageCircle size={22} fill="currentColor" /></span>
                <span><span className="block text-sm font-extrabold text-cream">WhatsApp — Fastest</span><span className="text-[11px] text-cream-dim">Under 2-minute reply, 24/7</span></span>
              </a>
              <a href={telLink} className="flex items-center gap-3 rounded-2xl border border-gold-500/30 bg-ink-700 px-4 py-4 transition-all hover:border-gold-500/50">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gold-500 text-ink-950"><Phone size={20} /></span>
                <span><span className="block text-sm font-extrabold text-cream">{site.phoneDisplay}</span><span className="text-[11px] text-cream-dim">Direct line — 24/7, private number</span></span>
              </a>
              <a href={mailLink} className="flex items-center gap-3 rounded-2xl border border-gold-500/20 bg-ink-700 px-4 py-4 transition-all hover:border-gold-500/40">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-gold-500/40 text-gold-400"><Mail size={20} /></span>
                <span><span className="block break-all text-sm font-bold text-cream">{site.email}</span><span className="text-[11px] text-cream-dim">For corporate &amp; event enquiries</span></span>
              </a>
            </div>
            <ul className="mt-5 space-y-1.5 border-t border-gold-500/10 pt-4 text-[11px] text-cream-dim">
              <li className="flex items-start gap-2"><MapPin size={13} className="mt-0.5 shrink-0 text-gold-500" />{site.address.street}, {site.address.city}, {site.address.region} {site.address.postalCode}</li>
              <li className="flex items-start gap-2"><Clock size={13} className="mt-0.5 shrink-0 text-gold-500" />{site.hours}</li>
              <li className="flex items-start gap-2"><ShieldCheck size={13} className="mt-0.5 shrink-0 text-emerald-400" />Private number · No caller ID · No data stored</li>
              <li className="flex items-start gap-2"><Star size={13} className="mt-0.5 shrink-0 text-gold-500" />4.9 rating · 1,900+ verified reviews</li>
            </ul>
          </div>

          <iframe
            title="Hyderabad Escorts Girls on Google Maps — Banjara Hills, Hyderabad"
            src={`https://www.google.com/maps?q=${encodeURIComponent("Banjara Hills, Hyderabad")}&output=embed`}
            className="h-56 w-full rounded-3xl border border-gold-500/20 grayscale invert-[0.92] hue-rotate-180"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </>
  );
}
