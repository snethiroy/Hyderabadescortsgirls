// FAQ content — also serialised to FAQPage JSON-LD on /faq
export type Faq = { q: string; a: string };

export const FAQS: Faq[] = [
  {
    q: "How do I book an escort in Hyderabad with you?",
    a: "It takes under two minutes — tap the WhatsApp button or call +91 70088 33477, tell us your preferred area, date, time and the profile you liked. Our coordinator confirms availability, shares a short verification ping, and your companion is dispatched. You can also use the booking form on this website.",
  },
  {
    q: "Are the escort profiles on Hyderabad Escorts Girls genuine?",
    a: "Yes. Every listed companion submits a government photo ID and a live verification selfie before being published, and photos are refreshed every 30 days. If a profile ever feels off, tell us — it is removed instantly and we refund any advance without question.",
  },
  {
    q: "Which areas of Hyderabad do you cover?",
    a: "We cover all of Hyderabad, Secunderabad and Cyberabad — Banjara Hills, Jubilee Hills, Gachibowli, Hitech City, Kondapur, Madhapur, Somajiguda, Begumpet, Khairatabad, Panjagutta, Lakdikapul, Abids, Secunderabad, Kukatpally, Miyapur, Manikonda, Uppal, LB Nagar, Tolichowki and every locality listed on our Areas page. Outstation bookings (Shamshabad airport, hotels en route) are arranged on request.",
  },
  {
    q: "Incall or outcall — what do you offer?",
    a: "Both. Incall means you visit our discreet, hotel-grade apartments in Banjara Hills by prior booking. Outcall means your companion reaches your hotel, service apartment or residence — whichever you prefer, with full address confidentiality.",
  },
  {
    q: "Is everything completely discreet and confidential?",
    a: "Absolute discretion is the foundation of our service. Companions arrive in plain civilian clothing with no branding, calls and messages stay between you and our coordinator, and we never store your details, photos or chat history beyond the booking itself. Client privacy is non-negotiable.",
  },
  {
    q: "How much does an escort in Hyderabad cost?",
    a: "Rates start from ₹3,000/hour for standard profiles and go up to ₹25,000/hour for VIP and celebrity-grade companions. Full overnight, dinner-date and travel packages are priced on request. All rates are quoted upfront before confirmation — no hidden charges, ever.",
  },
  {
    q: "Do I need to pay any advance?",
    a: "A nominal token advance may be requested only for outstation outcalls or peak-hour same-hour dispatches. Payment itself is made after arrival, by cash or any UPI app. We never ask for bank transfers or gift cards — that is a red flag you should avoid with any agency.",
  },
  {
    q: "Can I cancel or reschedule my booking?",
    a: "Yes — free cancellation or rescheduling up to 2 hours before the scheduled time. Inside 2 hours, the token advance (if any) is adjusted against your next booking instead of forfeited.",
  },
  {
    q: "What are your service hours?",
    a: "We operate 24 hours a day, 365 days a year — including Sundays and public holidays. Late-night (11 PM – 5 AM) bookings are our specialty, with GPS-tracked dispatch and 20–40 minute average arrival across West and Central Hyderabad.",
  },
  {
    q: "What is your age and consent policy?",
    a: "Strictly 18+. Every companion is an adult, independent individual who sets her own boundaries and can decline any request at any time. Hyderabad Escorts Girls provides social companionship and dating services only — we do not broker, solicit or facilitate sexual services, and any such demand is refused immediately.",
  },
  {
    q: "Can I book for a dinner date or corporate event?",
    a: "Absolutely — dinner companions, party plus-ones and corporate-event escorts are among our most popular services. Tell the coordinator the venue, dress code and duration, and we will match you with someone who fits the occasion perfectly.",
  },
  {
    q: "How do I know the person arriving is the same as the profile photo?",
    a: "Every dispatch shares a one-time OTP and the first name of your companion. Profiles carry a 'Verified' badge with a photo-match guarantee — if the person who arrives is not the profile booked, walk away, message us, and you pay nothing plus receive credit on your next booking.",
  },
];

export const FAQ_ITEMSLD = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: FAQS.map((f) => ({
    "@type": "Question",
    name: f.q,
    acceptedAnswer: { "@type": "Answer", text: f.a },
  })),
};
