"use client";

import { useState, type FormEvent } from "react";
import { CheckCircle2, Loader2, Send, MessageCircle } from "lucide-react";
import { AREAS } from "@/data/areas";
import { whatsappLink } from "@/lib/site";

export default function BookingForm({ source = "website" }: { source?: string }) {
  const [status, setStatus] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("sending");
    setErrorMsg("");
    const form = e.currentTarget;
    const fd = new FormData(form);
    const payload = {
      name: String(fd.get("name") ?? "").trim(),
      mobile: String(fd.get("mobile") ?? "").trim(),
      area: String(fd.get("area") ?? "").trim(),
      forDate: String(fd.get("forDate") ?? "").trim(),
      message: String(fd.get("message") ?? "").trim(),
      company: String(fd.get("company") ?? ""), // honeypot
      source,
    };
    try {
      const res = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (!res.ok || !data.ok) {
        setStatus("error");
        setErrorMsg(data.error ?? "Could not send your enquiry. Please WhatsApp us instead.");
        return;
      }
      setStatus("done");
      form.reset();
    } catch {
      setStatus("error");
      setErrorMsg("Network error — please try WhatsApp or call us directly.");
    }
  }

  if (status === "done") {
    return (
      <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-6 text-center">
        <CheckCircle2 className="mx-auto mb-3 text-emerald-400" size={40} />
        <h3 className="font-display text-xl font-bold text-cream">Enquiry received!</h3>
        <p className="mt-2 text-sm text-cream-dim">
          Our coordinator will call you within <strong className="text-cream">2 minutes</strong> to
          confirm availability, rates and arrival time. For the fastest confirmation, ping us on WhatsApp:
        </p>
        <a
          href={whatsappLink("Hello! I just submitted the booking form on your website.")}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 inline-flex items-center gap-2 rounded-xl bg-[#25D366] px-5 py-3 text-sm font-extrabold text-[#083b1e] transition-transform hover:scale-105"
        >
          <MessageCircle size={17} fill="currentColor" /> Open WhatsApp
        </a>
        <button
          onClick={() => setStatus("idle")}
          className="mt-3 block w-full text-center text-xs text-cream-dim underline-offset-2 hover:underline"
        >
          Send another enquiry
        </button>
      </div>
    );
  }

  const field =
    "w-full rounded-xl border border-gold-500/20 bg-ink-800 px-4 py-3 text-sm text-cream placeholder-cream-dim/50 outline-none transition-all focus:border-gold-500/60 focus:ring-2 focus:ring-gold-500/20";

  return (
    <form onSubmit={onSubmit} className="space-y-3" noValidate={false}>
      {/* Honeypot — hidden from humans */}
      <input type="text" name="company" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block text-xs font-semibold text-cream-dim">
          Your Name *
          <input required name="name" minLength={2} maxLength={80} placeholder="e.g. Rahul" className={`${field} mt-1.5`} />
        </label>
        <label className="block text-xs font-semibold text-cream-dim">
          Mobile / WhatsApp *
          <input
            required
            name="mobile"
            inputMode="numeric"
            pattern="[+]?[0-9][0-9 ]{9,14}"
            title="Enter a valid 10-digit Indian mobile number"
            placeholder="e.g. 98765 43210"
            className={`${field} mt-1.5`}
          />
        </label>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block text-xs font-semibold text-cream-dim">
          Your Area
          <select name="area" className={`${field} mt-1.5`} defaultValue="">
            <option value="">Select area…</option>
            {AREAS.map((a) => (
              <option key={a.slug} value={a.name.replace(/\s*\(.*?\)\s*/g, "")}>
                {a.name}
              </option>
            ))}
          </select>
        </label>
        <label className="block text-xs font-semibold text-cream-dim">
          Preferred Date &amp; Time
          <input name="forDate" type="datetime-local" className={`${field} mt-1.5`} />
        </label>
      </div>

      <label className="block text-xs font-semibold text-cream-dim">
        Your Message
        <textarea
          name="message"
          rows={3}
          maxLength={500}
          placeholder="e.g. Looking for a companion near Banjara Hills tonight around 10 PM, 2 hours. Dinner date."
          className={`${field} mt-1.5`}
        />
      </label>

      <label className="flex cursor-pointer items-start gap-2 text-[11px] leading-snug text-cream-dim">
        <input required type="checkbox" className="mt-0.5 accent-[#d4af37]" />
        I am 18+ and I confirm I want adult companionship services only. I understand Hyderabad Escorts
        Girls does not broker or facilitate sexual services.
      </label>

      {status === "error" && (
        <p role="alert" className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-xs text-rose-300">
          {errorMsg}
        </p>
      )}

      <button
        type="submit"
        disabled={status === "sending"}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-gold-400 to-gold-600 px-6 py-4 text-sm font-extrabold uppercase tracking-widest text-ink-950 transition-all hover:brightness-110 disabled:opacity-60"
      >
        {status === "sending" ? (
          <><Loader2 size={17} className="animate-spin" /> Sending…</>
        ) : (
          <><Send size={17} /> Request Callback Now</>
        )}
      </button>
      <p className="text-center text-[10px] text-cream-dim/70">
        Confidential. Your details are never shared. We call from a private number.
      </p>
    </form>
  );
}
