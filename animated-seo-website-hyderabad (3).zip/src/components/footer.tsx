import Link from "next/link";
import { Crown, Phone, MessageCircle, Mail, MapPin, Clock, ShieldCheck } from "lucide-react";
import { site, telLink, whatsappLink, mailLink } from "@/lib/site";
import { AREAS } from "@/data/areas";

export default function Footer() {
  return (
    <footer className="border-t border-gold-500/20 bg-ink-950 text-cream-dim">
      {/* SEO area link matrix */}
      <div className="border-b border-gold-500/10">
        <div className="mx-auto max-w-7xl px-4 py-6 lg:px-6">
          <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-gold-500">
            Serving Every Corner of Hyderabad — 24/7 Outcall &amp; Incall
          </p>
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5">
            {AREAS.map((a) => (
              <Link
                key={a.slug}
                href={`/areas/${a.slug}`}
                className="text-[11px] text-cream-dim/80 transition-colors hover:text-gold-300"
              >
                Escorts in {a.name.replace(/\s*\(.*?\)\s*/g, "")}
              </Link>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-2 lg:grid-cols-12 lg:px-6">
        {/* Brand */}
        <div className="lg:col-span-3">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-gold-300 to-gold-700 text-ink-950">
              <Crown size={19} fill="currentColor" />
            </span>
            <span className="font-display text-lg font-bold text-cream">
              Hyderabad <span className="text-gold-400">Escorts</span> Girls
            </span>
          </Link>
          <p className="mt-4 text-[13px] leading-relaxed">
            Hyderabad&apos;s most trusted companionship agency — verified, adult, independent
            companions for dinner dates, corporate events, travel and private company across
            Hyderabad, Secunderabad &amp; Cyberabad.
          </p>
          <p className="mt-4 inline-flex items-center gap-1.5 rounded-full border border-gold-500/30 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-gold-400">
            <ShieldCheck size={12} /> RTA-5042-1996-1400-1577-RTA · 18+ Only
          </p>
        </div>

        {/* Quick links */}
        <nav className="lg:col-span-2" aria-label="Quick links">
          <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-gold-500">Explore</p>
          <ul className="mt-3 space-y-2 text-[13px]">
            {[
              ["Home", "/"],
              ["All Companions", "/companions"],
              ["VIP Models", "/companions?category=VIP Model"],
              ["Independent", "/companions?category=Independent"],
              ["Elite Companions", "/companions?category=Elite"],
              ["Services & Rates", "/services"],
              ["FAQ", "/faq"],
              ["Blog", "/blog"],
              ["About Us", "/about"],
              ["Book Now", "/contact"],
            ].map(([label, href]) => (
              <li key={href}>
                <Link href={href} className="transition-colors hover:text-gold-300">{label}</Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Categories */}
        <nav className="lg:col-span-3" aria-label="Services">
          <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-gold-500">Services</p>
          <ul className="mt-3 space-y-2 text-[13px]">
            {[
              ["VIP Escort Service", "/services#vip"],
              ["Independent Escorts", "/services#independent"],
              ["Dinner Date Companions", "/services#dinner"],
              ["Corporate Event Escorts", "/services#corporate"],
              ["Travel Companion", "/services#travel"],
              ["Hotel Outcall (24/7)", "/services#outcall"],
              ["Private Incall Apartment", "/services#incall"],
              ["Overnight & Extended Bookings", "/services#overnight"],
              ["All Service Areas", "/areas"],
            ].map(([label, href]) => (
              <li key={href}>
                <Link href={href} className="transition-colors hover:text-gold-300">{label}</Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Contact */}
        <div className="lg:col-span-4">
          <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-gold-500">Contact — 24/7</p>
          <ul className="mt-3 space-y-2.5 text-[13px]">
            <li>
              <a href={telLink} className="flex items-start gap-2 transition-colors hover:text-gold-300">
                <Phone size={15} className="mt-0.5 shrink-0 text-gold-500" />
                <span><strong className="text-cream">{site.phoneDisplay}</strong><br />Call anytime, day or night</span>
              </a>
            </li>
            <li>
              <a href={whatsappLink("Hello Hyderabad Escorts Girls! I would like to book a companion.")} target="_blank" rel="noopener noreferrer" className="flex items-start gap-2 transition-colors hover:text-gold-300">
                <MessageCircle size={15} className="mt-0.5 shrink-0 text-gold-500" />
                <span><strong className="text-cream">WhatsApp Chat</strong><br />Fastest reply — under 2 minutes</span>
              </a>
            </li>
            <li>
              <a href={mailLink} className="flex items-start gap-2 transition-colors hover:text-gold-300">
                <Mail size={15} className="mt-0.5 shrink-0 text-gold-500" />
                <span>{site.email}</span>
              </a>
            </li>
            <li className="flex items-start gap-2">
              <MapPin size={15} className="mt-0.5 shrink-0 text-gold-500" />
              <span>{site.address.street}, {site.address.city}, {site.address.region} {site.address.postalCode}</span>
            </li>
            <li className="flex items-start gap-2">
              <Clock size={15} className="mt-0.5 shrink-0 text-gold-500" />
              <span>{site.hours}</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Legal */}
      <div className="border-t border-gold-500/10">
        <div className="mx-auto max-w-7xl px-4 py-6 text-[11px] leading-relaxed text-cream-dim/70 lg:px-6">
          <p>
            <strong className="text-cream-dim">Disclaimer:</strong> {site.name} is an adult social
            companionship and dating agency. We strictly do not offer, solicit or facilitate sexual
            services for payment. All listed companions are independent adults (18+) who set their own
            boundaries and may decline any request. Profiles use professional photography; actual
            appearance is verified against the same person who arrives. Client privacy is protected —
            we never share, sell or store personal data beyond a booking. If you are under 18, please
            leave this site immediately. Companionship is subject to availability and our Terms of Service.
          </p>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
            <p>© {new Date().getFullYear()} {site.name} · {site.domain}. All rights reserved.</p>
            <nav className="flex flex-wrap items-center gap-4" aria-label="Legal">
              <Link href="/privacy" className="hover:text-gold-300">Privacy Policy</Link>
              <Link href="/terms" className="hover:text-gold-300">Terms of Service</Link>
              <Link href="/disclaimer" className="hover:text-gold-300">Disclaimer</Link>
              <Link href="/about" className="hover:text-gold-300">About</Link>
              <a href="/sitemap.xml" className="hover:text-gold-300">Sitemap</a>
            </nav>
          </div>
        </div>
      </div>
    </footer>
  );
}
