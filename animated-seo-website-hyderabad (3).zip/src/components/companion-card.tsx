import Link from "next/link";
import Image from "next/image";
import { MapPin, Star, BadgeCheck, MessageCircle, Sparkles } from "lucide-react";
import { whatsappLink } from "@/lib/site";
import type { Companion } from "@/db/schema";

const AVAIL = {
  now: { label: "Available Now", dot: "bg-emerald-400", pulse: true },
  today: { label: "Available Today", dot: "bg-amber-400", pulse: false },
  request: { label: "On Request", dot: "bg-rose-400", pulse: false },
} as const;

export default function CompanionCard({ c }: { c: Companion }) {
  const avail = AVAIL[c.availability as keyof typeof AVAIL] ?? AVAIL.today;

  return (
    <article className="group relative flex flex-col overflow-hidden rounded-2xl border border-gold-500/15 bg-ink-800 transition-all duration-300 hover:-translate-y-1 hover:border-gold-500/40 hover:shadow-[0_24px_60px_rgba(212,175,55,0.12)]">
      {/* Photo */}
      <Link href={`/companions/${c.slug}`} className="relative block aspect-[3/4] w-full overflow-hidden" tabIndex={-1} aria-hidden>
        <Image
          src={c.image}
          alt={`${c.name} — verified ${c.category} escort in ${c.basedArea}, Hyderabad`}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-cover object-top transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/25 to-transparent" />
        {/* Top badges */}
        <div className="absolute left-2.5 top-2.5 flex flex-col items-start gap-1.5">
          <span className="rounded-full bg-gold-500 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-widest text-ink-950 shadow">
            {c.category}
          </span>
          {c.featured && (
            <span className="inline-flex items-center gap-1 rounded-full bg-ink-950/80 px-2.5 py-1 text-[9px] font-bold uppercase tracking-widest text-gold-300 backdrop-blur">
              <Sparkles size={10} /> Featured
            </span>
          )}
        </div>
        {c.verified && (
          <span className="absolute right-2.5 top-2.5 inline-flex items-center gap-1 rounded-full bg-emerald-500/90 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-widest text-emerald-950 backdrop-blur">
            <BadgeCheck size={11} /> Verified
          </span>
        )}
      </Link>

      {/* Body */}
      <div className="flex flex-1 flex-col gap-1.5 p-3 sm:p-4">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-display text-lg font-bold text-cream sm:text-xl">
            <Link href={`/companions/${c.slug}`} className="hover:text-gold-300">{c.name}</Link>
            <span className="ml-1.5 text-sm font-semibold text-cream-dim">{c.age}</span>
          </h3>
          <span className="inline-flex items-center gap-1 text-xs font-bold text-gold-300">
            <Star size={12} fill="currentColor" /> {c.rating.toFixed(1)}
            <span className="font-medium text-cream-dim">({c.reviews})</span>
          </span>
        </div>

        <p className="flex items-center gap-1 text-[11px] text-cream-dim">
          <MapPin size={11} className="text-gold-500" /> {c.basedArea}, Hyderabad
        </p>
        <p className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-cream-dim">
          <span className={`inline-block h-1.5 w-1.5 rounded-full ${avail.dot} ${avail.pulse ? "animate-pulse" : ""}`} />
          {avail.label}
        </p>

        <div className="mt-auto flex items-end justify-between gap-2 border-t border-gold-500/10 pt-2.5">
          <div>
            <p className="font-display text-lg font-extrabold leading-none text-gold-400">
              ₹{c.priceInr.toLocaleString("en-IN")}
            </p>
            <p className="mt-0.5 text-[9px] font-semibold uppercase tracking-widest text-cream-dim">per hour</p>
          </div>
          <div className="flex items-center gap-1.5">
            <a
              href={whatsappLink(`Hello Hyderabad Escorts Girls! I would like to book ${c.name} (${c.basedArea}).`)}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`Book ${c.name} on WhatsApp`}
              className="grid h-9 w-9 place-items-center rounded-xl bg-[#25D366] text-[#083b1e] transition-transform hover:scale-110"
            >
              <MessageCircle size={18} strokeWidth={2.2} fill="currentColor" />
            </a>
            <Link
              href={`/companions/${c.slug}`}
              className="rounded-xl border border-gold-500/40 bg-ink-700 px-3 py-2 text-[11px] font-bold uppercase tracking-wide text-gold-300 transition-colors hover:border-gold-500 hover:text-gold-200"
            >
              View
            </Link>
          </div>
        </div>
      </div>
    </article>
  );
}
