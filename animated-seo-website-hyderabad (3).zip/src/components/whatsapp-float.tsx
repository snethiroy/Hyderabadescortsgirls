import { MessageCircle } from "lucide-react";
import { whatsappLink } from "@/lib/site";

export default function WhatsAppFloat() {
  return (
    <a
      href={whatsappLink("Hello Hyderabad Escorts Girls! I would like to book a companion.")}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp — 24/7"
      className="group fixed bottom-5 right-4 z-40 flex items-center gap-2 sm:bottom-6 sm:right-6"
    >
      <span className="pointer-events-none rounded-xl border border-emerald-500/30 bg-ink-950/95 px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-emerald-400 opacity-0 shadow-lg backdrop-blur transition-all duration-300 group-hover:opacity-100">
        Chat 24/7 — 2 min reply
      </span>
      <span className="relative grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-[#083b1e] shadow-[0_10px_30px_rgba(37,211,102,0.45)] transition-transform hover:scale-110">
        <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-[#25D366]/40" />
        <MessageCircle size={28} strokeWidth={2.2} fill="currentColor" />
      </span>
    </a>
  );
}
