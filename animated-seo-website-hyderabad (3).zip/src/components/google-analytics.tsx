import Script from "next/script";

// Rendered only when NEXT_PUBLIC_GA_MEASUREMENT_ID is set (e.g. "G-XXXXXXXXXX").
// Keeps the site analytics-free for users/servers without the env var.
const GA_ID = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID;

export default function GoogleAnalytics() {
  if (!GA_ID) return null;
  return (
    <>
      <Script
        src={`https://www.googletagmanager.com/gtag/js?id=${GA_ID}`}
        strategy="afterInteractive"
      />
      <Script id="ga4-config" strategy="afterInteractive">
        {`
          window.dataLayer = window.dataLayer || [];
          function gtag(){ window.dataLayer.push(arguments); }
          gtag('js', new Date());
          gtag('config', '${GA_ID}', { anonymize_ip: true, transport_type: 'beacon' });
        `}
      </Script>
    </>
  );
}
