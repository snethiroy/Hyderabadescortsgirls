"use client";

import { useEffect, useState } from "react";

// High-volume Hyderabad search keywords — rotated with a typewriter effect.
const KEYWORDS = [
  "Hyderabad Escorts",
  "Hyderabad Escorts Girls",
  "Independent Escorts in Hyderabad",
  "VIP Escorts in Banjara Hills",
  "Escorts in Gachibowli",
  "Hitech City Escort Service",
  "Jubilee Hills Escorts",
  "Elite Escorts Hyderabad",
  "Secunderabad Escorts 24/7",
  "Escorts in Kukatpally",
  "High Profile Escorts Hyderabad",
  "Same-Hour Escort Dispatch",
];

export default function KeywordCycler() {
  const [index, setIndex] = useState(0);
  const [text, setText] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = KEYWORDS[index % KEYWORDS.length];
    let timeout: ReturnType<typeof setTimeout>;

    if (!deleting && text === current) {
      // Hold the completed phrase, then start deleting
      timeout = setTimeout(() => setDeleting(true), 1600);
    } else if (deleting && text === "") {
      setDeleting(false);
      setIndex((i) => (i + 1) % KEYWORDS.length);
    } else {
      timeout = setTimeout(
        () => setText(deleting ? current.slice(0, text.length - 1) : current.slice(0, text.length + 1)),
        deleting ? 26 : 58
      );
    }
    return () => clearTimeout(timeout);
  }, [text, deleting, index]);

  return (
    <span
      aria-live="polite"
      aria-label={`Trending: ${KEYWORDS[index % KEYWORDS.length]}`}
      className="inline-flex min-h-[1.2em] items-baseline"
    >
      <span className="text-gold-gradient font-bold">{text}</span>
      <span aria-hidden="true" className="caret-blink ml-1 inline-block h-[0.95em] w-[0.28em] translate-y-[0.08em] rounded-[2px] bg-gold-400" />
    </span>
  );
}
