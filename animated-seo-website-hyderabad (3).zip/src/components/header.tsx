"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X, Phone, Crown, MessageCircle, Mail, Clock } from "lucide-react";
import { site, telLink, whatsappLink } from "@/lib/site";

const NAV = [
  { label: "Home", href: "/" },
  { label: "Companions", href: "/companions" },
  { label: "Areas", href: "/areas" },
  { label: "Services", href: "/services" },
  { label: "Blog", href: "/blog" },
  { label: "Contact", href: "/contact" },
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50">
      {/* Top service strip */}
      <div className="hidden border-b border-gold-500/15 bg-ink-950 text-[11px] tracking-wide text-cream-dim md:block">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-1.5 lg:px-6">
          <div className="flex items-center gap-4">
            <span className="inline-flex items-center gap-1.5">
              <Clock size={11} className="text-gold-400" /> 24/7 Same-Hour Dispatch
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
              150+ Verified Profiles Live
            </span>
            <span className="text-gold-500/80">18+ Only · RTA Verified</span>
          </div>
          <a href={`mailto:${site.email}`} className="inline-flex items-center gap-1.5 hover:text-cream">
            <Mail size={11} className="text-gold-400" /> {site.email}
          </a>
        </div>
      </div>

      {/* Main navbar */}
      <div className="border-b border-gold-500/20 bg-ink-950/90 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4 lg:h-[72px] lg:px-6">
          {/* Logo */}
          <Link href="/" className="group flex min-w-0 items-center gap-2.5" aria-label="Hyderabad Escorts Girls — Home">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-gold-300 via-gold-500 to-gold-700 text-ink-950 shadow-[0_0_24px_rgba(212,175,55,0.35)] transition-transform group-hover:scale-105">
              <Crown size={20} strokeWidth={2.2} fill="currentColor" />
            </span>
            <span className="min-w-0 leading-tight">
              <span className="block truncate font-display text-[17px] font-bold tracking-tight text-cream sm:text-lg">
                Hyderabad <span className="text-gold-400">Escorts</span> Girls
              </span>
              <span className="block text-[10px] font-medium uppercase tracking-[0.22em] text-cream-dim">
                hyderabadescortsgirls.com
              </span>
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden items-center gap-6 lg:flex" aria-label="Primary navigation">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-[13px] font-semibold uppercase tracking-wider text-cream-dim transition-colors hover:text-gold-300"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex shrink-0 items-center gap-2">
            <a
              href={telLink}
              className="hidden items-center gap-2 rounded-xl border border-gold-500/30 bg-ink-800 px-3 py-2 text-sm font-semibold text-gold-300 transition-colors hover:border-gold-500/60 hover:text-gold-200 md:flex"
            >
              <Phone size={15} /> {site.phoneDisplay}
            </a>
            <a
              href={whatsappLink("Hello Hyderabad Escorts Girls! I would like to book a companion.")}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden items-center gap-2 rounded-xl bg-gradient-to-r from-gold-400 to-gold-600 px-4 py-2 text-sm font-extrabold uppercase tracking-wide text-ink-950 shadow-[0_6px_20px_rgba(212,175,55,0.35)] transition-all hover:brightness-110 sm:flex"
            >
              <MessageCircle size={15} strokeWidth={2.5} /> Book Now
            </a>
            <button
              onClick={() => setOpen((v) => !v)}
              className="grid h-10 w-10 place-items-center rounded-xl border border-gold-500/25 text-gold-300 lg:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
            >
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {open && (
          <div className="border-t border-gold-500/15 bg-ink-950/98 px-4 pb-5 pt-3 backdrop-blur-xl lg:hidden">
            <nav className="grid grid-cols-2 gap-2" aria-label="Mobile navigation">
              {NAV.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="rounded-xl border border-gold-500/15 bg-ink-800 px-4 py-3 text-sm font-semibold text-cream"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <a href={telLink} className="flex items-center justify-center gap-2 rounded-xl border border-gold-500/40 py-3 text-sm font-bold text-gold-300">
                <Phone size={16} /> Call
              </a>
              <a
                href={whatsappLink("Hello Hyderabad Escorts Girls! I would like to book a companion.")}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-gold-400 to-gold-600 py-3 text-sm font-extrabold text-ink-950"
              >
                <MessageCircle size={16} /> WhatsApp
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
