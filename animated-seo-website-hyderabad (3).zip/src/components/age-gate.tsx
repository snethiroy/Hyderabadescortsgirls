"use client";

import { useEffect, useState } from "react";
import { Crown, ShieldCheck, LogIn, LogOut } from "lucide-react";
import { site } from "@/lib/site";

const KEY = "heg-age-verified";

export default function AgeGate() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      if (window.localStorage.getItem(KEY) !== "yes") {
        setVisible(true);
        document.body.style.overflow = "hidden";
      }
    } catch {
      setVisible(true);
    }
  }, []);

  if (!visible) return null;

  const enter = () => {
    try {
      window.localStorage.setItem(KEY, "yes");
    } catch {
      /* private mode */
    }
    document.body.style.overflow = "";
    setVisible(false);
  };

  const leave = () => {
    window.location.href = "https://www.google.com";
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="age-gate-title"
      className="fixed inset-0 z-[100] flex items-center justify-center bg-ink-950/92 p-4 backdrop-blur-md"
    >
      <div className="w-full max-w-md overflow-hidden rounded-3xl border border-gold-500/30 bg-ink-900 shadow-[0_40px_120px_rgba(0,0,0,0.7)]">
        <div className="relative bg-gradient-to-br from-gold-500/15 via-transparent to-transparent px-8 pb-6 pt-8 text-center">
          <span className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-gold-300 to-gold-700 text-ink-950">
            <Crown size={30} strokeWidth={2.2} fill="currentColor" />
          </span>
          <p className="text-[10px] font-bold uppercase tracking-[0.35em] text-gold-500">{site.domain}</p>
          <h2 id="age-gate-title" className="mt-2 font-display text-2xl font-bold text-cream">
            Adults Only — 18+
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-cream-dim">
            This website provides adult companionship services and contains profiles of adult
            entertainers. By entering, you confirm that you are <strong className="text-cream">18 years or older</strong>,
            that adult companionship content is legal where you live, and that you accept our Terms &amp; Privacy Policy.
          </p>
          <p className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-gold-500/30 bg-ink-800 px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-gold-400">
            <ShieldCheck size={12} /> RTA-5042-1996-1400-1577-RTA
          </p>
        </div>
        <div className="grid grid-cols-2 gap-3 border-t border-gold-500/15 bg-ink-950/60 p-4">
          <button
            onClick={leave}
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-ink-600 px-4 py-3 text-sm font-semibold text-cream-dim transition-colors hover:border-ink-600/50 hover:text-cream"
          >
            <LogOut size={16} /> I&apos;m Under 18
          </button>
          <button
            onClick={enter}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-gold-400 to-gold-600 px-4 py-3 text-sm font-extrabold uppercase tracking-wide text-ink-950 transition-all hover:brightness-110"
          >
            <LogIn size={16} /> I Am 18+
          </button>
        </div>
      </div>
    </div>
  );
}
