# Go-Live on Google — Hyderabad Escorts Girls (Option A)

Everything code-side is done: canonical tags, meta titles/descriptions, OpenGraph/Twitter cards,
RTA label, sitemap.xml (57 URLs), robots.txt, JSON-LD (LocalBusiness, WebSite, FAQPage,
BreadcrumbList, ItemList, ProfilePage, BlogPosting), 32 static area pages, internal keyword
linking, and env-gated Search Console verification + GA4. This document is the exact runbook
to take it from this repo to **indexed on Google**.

Production origin assumed below: `https://www.hyderabadescortsgirls.com`
(change it via `NEXT_PUBLIC_SITE_URL` if you deploy elsewhere).

---

## 1. Deploy the production build

```bash
npm ci
npx drizzle-kit push        # apply schema (companions, enquiries) to the production Postgres
npm run build
npm run start               # or your platform's equivalent (Vercel/PM2/Docker)
```

Health check must return 200: `GET https://www.hyderabadescortsgirls.com/api/health`

Minimum DNS records at your registrar / DNS host:

| Type | Host | Value |
|------|------|-------|
| A / ALIAS / CNAME | `@` or `www` | your hosting target |
| CNAME | `www` | root host (if apex is A-record) |

Force-HTTPS and HTTP→HTTPS redirect at the edge (most hosts do this automatically).

## 2. Prove ownership to Google Search Console

1. Go to https://search.google.com/search-console → **Add property**.
2. Prefer **Domain property** (covers http/https, www/non-www) → DNS TXT record
   `google-site-verification=XXXX` at your DNS host (fastest, recommended), **or**
3. **URL-prefix property** → choose **HTML tag** method → copy only the `content="..."` value →
   set env var and redeploy/restart:
   ```bash
   GOOGLE_SITE_VERIFICATION=<paste-token>
   ```
   The tag renders automatically on every page (already wired in `src/app/layout.tsx`).
   Verify with: `curl -s https://www.hyderabadescortsgirls.com/ | grep google-site-verification`
4. (Optional) **HTML file** method — drop the downloaded file into `public/` as-is and redeploy.

## 3. Submit the sitemap & request indexing

1. Search Console → **Sitemaps** → enter `sitemap.xml` → Submit. Expect **57 discovered URLs**.
2. **URL Inspection** → paste each priority URL → *Request indexing*:
   - `/` , `/companions`, `/services`, `/contact`
   - top area pages: `/areas/banjara-hills`, `/areas/gachibowli`, `/areas/hitech-city`,
     `/areas/jubilee-hills`, `/areas/kondapur`, `/areas/secunderabad`
   (quota is ~10–12 requests/day; the area pages are also crawlable via internal links.)
3. Search Console → **Pages** — watch “Indexed” grow over 1–4 weeks.

## 4. (Optional) Turn on Google Analytics 4

1. https://analytics.google.com → create property → Web stream → copy Measurement ID `G-XXXXXXXXXX`.
2. Set env var and restart:
   ```bash
   NEXT_PUBLIC_GA_MEASUREMENT_ID=G-XXXXXXXXXX
   ```
   gtag.js loads automatically (`src/components/google-analytics.tsx`), IP-anonymized.

## 5. Validate rich results & crawlability

- Rich Results Test: https://search.google.com/test/rich-results — test `/faq` (FAQPage),
  `/areas/banjara-hills` (BreadcrumbList + FAQPage), `/` (LocalBusiness/WebSite).
- **Mobile-Friendly Test**: pass — the layout is mobile-first.
- PageSpeed Insights: aim LCP < 2.5 s — hero image is prioritized `next/image` with AVIF/WebP.
- `robots.txt` serves: `Allow: /`, `Disallow: /api/`, `Sitemap: …/sitemap.xml` ✔

## 6. Post-launch ranking hygiene (ongoing, not code)

- Keep NAP (Name/Address/Phone: **Hyderabad Escorts Girls · Road No. 12, Banjara Hills ·
  +91 70088 33477 · snethiroy@gmail.com**) identical on every citation: Google Business Profile,
  Justdial, IndiaMART, Sulekha, social bios. Consistency is the #1 local-rank signal.
- Post the 3 blog guides on socials; backlinks from even small local directories help.
- Add 1–2 new verified companion profiles weekly (sitemap `lastModified` updates automatically).
- Reply to every review; keep photos refreshed (we re-verify profiles every 30 days).
- Do **not** buy links or keyword-stuff hidden text — Google spam policies will demote the site.

## 7. Adult-content & compliance notes (India)

- The site is RTA-labelled (`RTA-5042-1996-1400-1577-RTA`), 18+ age-gated, companionship-only,
  with clear disclaimers (`/disclaimer`) — required for lawful adult-industry operation.
- Google permits indexing of adult pages if they carry no deceptive practices and comply with
  SafeSearch labeling conventions — keep the RTA tag and avoid any sexual-explicit imagery.
- If a SafeSearch mismatch warning appears in Search Console → SafeSearch filtering, add the
  `adult` rating meta (already present as `other.rating`) and keep content non-explicit.

---

**Fastest path from zero → indexed:** DNS → HTTPS → `GOOGLE_SITE_VERIFICATION` (or DNS TXT) →
submit `sitemap.xml` → *Request indexing* for `/` → wait 3–14 days. That is the entire Google
"go-live". Everything else above compounds your ranking after that.
